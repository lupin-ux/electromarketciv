import { 
  users, products, categories, cartItems, orders, orderItems, phoneVerifications,
  type User, type InsertUser, 
  type Product, type InsertProduct,
  type Category, type InsertCategory,
  type CartItem, type InsertCartItem, type CartItemWithProduct,
  type Order, type InsertOrder,
  type OrderItem, type InsertOrderItem,
  type PhoneVerification, type InsertPhoneVerification
} from "@shared/schema";

// modify the interface with any CRUD methods
// you might need
export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, data: Partial<User>): Promise<User | undefined>;
  
  // Phone Verification
  createPhoneVerification(verification: InsertPhoneVerification): Promise<PhoneVerification>;
  getPhoneVerificationByCode(verificationCode: string): Promise<PhoneVerification | undefined>;
  getPhoneVerificationByPhoneNumber(phoneNumber: string): Promise<PhoneVerification | undefined>;
  verifyPhoneNumber(userId: number, verificationCode: string): Promise<boolean>;
  
  // Categories
  getCategories(): Promise<Category[]>;
  getCategory(id: number): Promise<Category | undefined>;
  getCategoryBySlug(slug: string): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;
  
  // Products
  getProducts(options?: { categoryId?: number, featured?: boolean, limit?: number }): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  getProductBySlug(slug: string): Promise<Product | undefined>;
  searchProducts(query: string): Promise<Product[]>;
  createProduct(product: InsertProduct): Promise<Product>;
  
  // Cart
  getCartItems(sessionId: string): Promise<CartItemWithProduct[]>;
  getCartItem(id: number): Promise<CartItem | undefined>;
  getCartItemByProductAndSession(productId: number, sessionId: string): Promise<CartItem | undefined>;
  createCartItem(cartItem: InsertCartItem): Promise<CartItem>;
  updateCartItem(id: number, quantity: number): Promise<CartItem | undefined>;
  deleteCartItem(id: number): Promise<boolean>;
  clearCart(sessionId: string): Promise<boolean>;
  
  // Orders
  getOrders(userId?: number, sessionId?: string): Promise<Order[]>;
  getOrder(id: number): Promise<Order | undefined>;
  createOrder(order: InsertOrder): Promise<Order>;
  getOrderItems(orderId: number): Promise<OrderItem[]>;
  createOrderItem(orderItem: InsertOrderItem): Promise<OrderItem>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private categories: Map<number, Category>;
  private products: Map<number, Product>;
  private cartItems: Map<number, CartItem>;
  private orders: Map<number, Order>;
  private orderItems: Map<number, OrderItem>;
  private phoneVerifications: Map<number, PhoneVerification>;
  private userIdCounter: number;
  private categoryIdCounter: number;
  private productIdCounter: number;
  private cartItemIdCounter: number;
  private orderIdCounter: number;
  private orderItemIdCounter: number;
  private phoneVerificationIdCounter: number;

  constructor() {
    this.users = new Map();
    this.categories = new Map();
    this.products = new Map();
    this.cartItems = new Map();
    this.orders = new Map();
    this.orderItems = new Map();
    this.phoneVerifications = new Map();
    this.userIdCounter = 1;
    this.categoryIdCounter = 1;
    this.productIdCounter = 1;
    this.cartItemIdCounter = 1;
    this.orderIdCounter = 1;
    this.orderItemIdCounter = 1;
    this.phoneVerificationIdCounter = 1;

    // Initialize with sample data
    this.initializeSampleData();
  }

  // Users
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { 
      ...insertUser, 
      id, 
      isAdmin: false, 
      isVerified: false,
      createdAt: new Date() 
    };
    this.users.set(id, user);
    return user;
  }
  
  async updateUser(id: number, data: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...data };
    this.users.set(id, updatedUser);
    return updatedUser;
  }
  
  // Phone Verification
  async createPhoneVerification(verification: InsertPhoneVerification): Promise<PhoneVerification> {
    const id = this.phoneVerificationIdCounter++;
    const phoneVerification: PhoneVerification = {
      ...verification,
      id,
      isVerified: false,
      createdAt: new Date()
    };
    this.phoneVerifications.set(id, phoneVerification);
    return phoneVerification;
  }
  
  async getPhoneVerificationByCode(verificationCode: string): Promise<PhoneVerification | undefined> {
    return Array.from(this.phoneVerifications.values()).find(
      (verification) => verification.verificationCode === verificationCode
    );
  }
  
  async getPhoneVerificationByPhoneNumber(phoneNumber: string): Promise<PhoneVerification | undefined> {
    // Get the most recent verification for this phone number
    const verifications = Array.from(this.phoneVerifications.values())
      .filter(verification => verification.phoneNumber === phoneNumber)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
    
    return verifications.length > 0 ? verifications[0] : undefined;
  }
  
  async verifyPhoneNumber(userId: number, verificationCode: string): Promise<boolean> {
    const verification = await this.getPhoneVerificationByCode(verificationCode);
    if (!verification) return false;
    
    // Check if verification is expired
    if (new Date() > verification.expiresAt) return false;
    
    // Mark the verification as verified
    const updatedVerification = { ...verification, isVerified: true };
    this.phoneVerifications.set(verification.id, updatedVerification);
    
    // Update the user as verified
    const user = await this.getUser(userId);
    if (user) {
      user.isVerified = true;
      user.phoneNumber = verification.phoneNumber;
      this.users.set(userId, user);
    }
    
    return true;
  }

  // Categories
  async getCategories(): Promise<Category[]> {
    return Array.from(this.categories.values());
  }

  async getCategory(id: number): Promise<Category | undefined> {
    return this.categories.get(id);
  }

  async getCategoryBySlug(slug: string): Promise<Category | undefined> {
    return Array.from(this.categories.values()).find(
      (category) => category.slug === slug,
    );
  }

  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    const id = this.categoryIdCounter++;
    const category: Category = { ...insertCategory, id };
    this.categories.set(id, category);
    return category;
  }

  // Products
  async getProducts(options?: { categoryId?: number, featured?: boolean, limit?: number }): Promise<Product[]> {
    let products = Array.from(this.products.values());
    
    if (options?.categoryId) {
      products = products.filter(product => product.categoryId === options.categoryId);
    }
    
    if (options?.featured !== undefined) {
      products = products.filter(product => product.featured === options.featured);
    }
    
    if (options?.limit) {
      products = products.slice(0, options.limit);
    }
    
    return products;
  }

  async getProduct(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async getProductBySlug(slug: string): Promise<Product | undefined> {
    return Array.from(this.products.values()).find(
      (product) => product.slug === slug,
    );
  }

  async searchProducts(query: string): Promise<Product[]> {
    const lowercaseQuery = query.toLowerCase();
    return Array.from(this.products.values()).filter(
      (product) => 
        product.name.toLowerCase().includes(lowercaseQuery) || 
        (product.description && product.description.toLowerCase().includes(lowercaseQuery))
    );
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const id = this.productIdCounter++;
    const product: Product = { 
      ...insertProduct, 
      id, 
      rating: 0, 
      reviewCount: 0,
      createdAt: new Date()
    };
    this.products.set(id, product);
    return product;
  }

  // Cart
  async getCartItems(sessionId: string): Promise<CartItemWithProduct[]> {
    const items = Array.from(this.cartItems.values()).filter(
      (item) => item.sessionId === sessionId
    );

    return items.map(item => {
      const product = this.products.get(item.productId);
      if (!product) {
        throw new Error(`Product with id ${item.productId} not found`);
      }
      return { ...item, product };
    });
  }

  async getCartItem(id: number): Promise<CartItem | undefined> {
    return this.cartItems.get(id);
  }

  async getCartItemByProductAndSession(productId: number, sessionId: string): Promise<CartItem | undefined> {
    return Array.from(this.cartItems.values()).find(
      (item) => item.productId === productId && item.sessionId === sessionId
    );
  }

  async createCartItem(insertCartItem: InsertCartItem): Promise<CartItem> {
    const id = this.cartItemIdCounter++;
    const cartItem: CartItem = { 
      ...insertCartItem, 
      id, 
      createdAt: new Date() 
    };
    this.cartItems.set(id, cartItem);
    return cartItem;
  }

  async updateCartItem(id: number, quantity: number): Promise<CartItem | undefined> {
    const cartItem = this.cartItems.get(id);
    if (!cartItem) return undefined;
    
    const updatedCartItem = { ...cartItem, quantity };
    this.cartItems.set(id, updatedCartItem);
    return updatedCartItem;
  }

  async deleteCartItem(id: number): Promise<boolean> {
    return this.cartItems.delete(id);
  }

  async clearCart(sessionId: string): Promise<boolean> {
    const items = Array.from(this.cartItems.values()).filter(
      (item) => item.sessionId === sessionId
    );
    
    for (const item of items) {
      this.cartItems.delete(item.id);
    }
    
    return true;
  }

  // Orders
  async getOrders(userId?: number, sessionId?: string): Promise<Order[]> {
    let orders = Array.from(this.orders.values());
    
    if (userId) {
      orders = orders.filter(order => order.userId === userId);
    }
    
    if (sessionId) {
      orders = orders.filter(order => order.sessionId === sessionId);
    }
    
    return orders;
  }

  async getOrder(id: number): Promise<Order | undefined> {
    return this.orders.get(id);
  }

  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const id = this.orderIdCounter++;
    const order: Order = { 
      ...insertOrder, 
      id, 
      createdAt: new Date() 
    };
    this.orders.set(id, order);
    return order;
  }

  async getOrderItems(orderId: number): Promise<OrderItem[]> {
    return Array.from(this.orderItems.values()).filter(
      (item) => item.orderId === orderId
    );
  }

  async createOrderItem(insertOrderItem: InsertOrderItem): Promise<OrderItem> {
    const id = this.orderItemIdCounter++;
    const orderItem: OrderItem = { 
      ...insertOrderItem, 
      id, 
      createdAt: new Date() 
    };
    this.orderItems.set(id, orderItem);
    return orderItem;
  }

  // Initialize with sample data
  private initializeSampleData() {
    // Categories
    const categories: InsertCategory[] = [
      {
        name: "Ordinateurs portables",
        slug: "ordinateurs-portables",
        description: "Ordinateurs portables pour tous les besoins",
        imageUrl: "https://images.unsplash.com/photo-1593642702821-c8da6771f0c6?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80"
      },
      {
        name: "Smartphones",
        slug: "smartphones",
        description: "Les derniers smartphones des meilleures marques",
        imageUrl: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80"
      },
      {
        name: "Tablettes",
        slug: "tablettes",
        description: "Tablettes pour le travail et les loisirs",
        imageUrl: "https://images.unsplash.com/photo-1616530940355-351fabd9524b?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80"
      },
      {
        name: "Audio",
        slug: "audio",
        description: "Casques, écouteurs et enceintes pour une expérience audio optimale",
        imageUrl: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80"
      },
      {
        name: "Accessoires",
        slug: "accessoires",
        description: "Accessoires pour tous vos appareils électroniques",
        imageUrl: "https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80"
      }
    ];

    categories.forEach(category => {
      this.createCategory(category);
    });

    // Products
    const products: InsertProduct[] = [
      {
        name: "MacBook Pro 13\" (2022)",
        slug: "macbook-pro-13-2022",
        description: "Ordinateur portable puissant pour les professionnels et les créatifs",
        price: 899000, // 899,000 FCFA
        discountPrice: 850000, // 850,000 FCFA
        imageUrl: "https://images.unsplash.com/photo-1496181133206-80ce9b88a853?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
        categoryId: 1,
        inStock: true,
        featured: true,
        isNew: false,
        specifications: {
          processor: "Apple M2",
          memory: "8GB",
          storage: "256GB SSD",
          display: "13.3 pouces Retina",
          os: "macOS"
        }
      },
      {
        name: "Samsung Galaxy S21 Ultra",
        slug: "samsung-galaxy-s21-ultra",
        description: "Smartphone haut de gamme avec appareil photo professionnel",
        price: 575000, // 575,000 FCFA
        discountPrice: null,
        imageUrl: "https://images.unsplash.com/photo-1585060544812-6b45742d762f?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
        categoryId: 2,
        inStock: true,
        featured: true,
        isNew: true,
        specifications: {
          processor: "Exynos 2100",
          memory: "12GB",
          storage: "256GB",
          display: "6.8 pouces Dynamic AMOLED 2X",
          camera: "108MP + 12MP + 10MP + 10MP",
          os: "Android"
        }
      },
      {
        name: "iPad Pro 11\" (2022)",
        slug: "ipad-pro-11-2022",
        description: "Tablette puissante pour les professionnels et les artistes",
        price: 490000, // 490,000 FCFA
        discountPrice: null,
        imageUrl: "https://images.unsplash.com/photo-1616530940355-351fabd9524b?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
        categoryId: 3,
        inStock: true,
        featured: true,
        isNew: false,
        specifications: {
          processor: "Apple M2",
          memory: "8GB",
          storage: "128GB",
          display: "11 pouces Liquid Retina",
          os: "iPadOS"
        }
      },
      {
        name: "Beats Studio3 Wireless",
        slug: "beats-studio3-wireless",
        description: "Casque sans fil avec réduction active du bruit",
        price: 95000, // 95,000 FCFA
        discountPrice: 75000, // 75,000 FCFA
        imageUrl: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
        categoryId: 4,
        inStock: true,
        featured: true,
        isNew: false,
        specifications: {
          type: "Casque circum-aural",
          connectivity: "Bluetooth",
          batteryLife: "22 heures",
          noiseCancelling: "Oui"
        }
      },
      {
        name: "HP Spectre x360",
        slug: "hp-spectre-x360",
        description: "Ordinateur portable convertible avec écran tactile",
        price: 750000, // 750,000 FCFA
        discountPrice: null,
        imageUrl: "https://images.unsplash.com/photo-1544731612-de7f96afe55f?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
        categoryId: 1,
        inStock: true,
        featured: false,
        isNew: true,
        specifications: {
          processor: "Intel Core i7",
          memory: "16GB",
          storage: "512GB SSD",
          display: "13.3 pouces tactile",
          os: "Windows 11"
        }
      },
      {
        name: "iPhone 13 Pro",
        slug: "iphone-13-pro",
        description: "Smartphone Apple avec système de caméra pro",
        price: 650000, // 650,000 FCFA
        discountPrice: 600000, // 600,000 FCFA
        imageUrl: "https://images.unsplash.com/photo-1632661674596-df8be070a5c5?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
        categoryId: 2,
        inStock: true,
        featured: false,
        isNew: false,
        specifications: {
          processor: "A15 Bionic",
          memory: "6GB",
          storage: "128GB",
          display: "6.1 pouces Super Retina XDR",
          camera: "12MP + 12MP + 12MP",
          os: "iOS"
        }
      },
      {
        name: "Samsung Galaxy Tab S8",
        slug: "samsung-galaxy-tab-s8",
        description: "Tablette Android haut de gamme avec stylet S Pen inclus",
        price: 420000, // 420,000 FCFA
        discountPrice: null,
        imageUrl: "https://images.unsplash.com/photo-1589739900869-082b93d8e923?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
        categoryId: 3,
        inStock: true,
        featured: false,
        isNew: true,
        specifications: {
          processor: "Snapdragon 8 Gen 1",
          memory: "8GB",
          storage: "128GB",
          display: "11 pouces LTPS TFT",
          os: "Android"
        }
      },
      {
        name: "Sony WH-1000XM4",
        slug: "sony-wh-1000xm4",
        description: "Casque sans fil avec la meilleure réduction de bruit du marché",
        price: 120000, // 120,000 FCFA
        discountPrice: null,
        imageUrl: "https://images.unsplash.com/photo-1548378329-437e1ef34263?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=80",
        categoryId: 4,
        inStock: true,
        featured: false,
        isNew: false,
        specifications: {
          type: "Casque circum-aural",
          connectivity: "Bluetooth",
          batteryLife: "30 heures",
          noiseCancelling: "Oui"
        }
      }
    ];

    products.forEach(product => {
      this.createProduct(product);
    });
  }
}

export const storage = new MemStorage();
