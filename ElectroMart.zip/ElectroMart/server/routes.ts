import express, { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { v4 as uuidv4 } from "uuid";
import { insertCartItemSchema, insertOrderSchema, insertOrderItemSchema, insertPhoneVerificationSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // prefix all routes with /api
  const apiRouter = express.Router();
  app.use('/api', apiRouter);

  // Categories
  apiRouter.get("/categories", async (req, res) => {
    try {
      const categories = await storage.getCategories();
      res.json(categories);
    } catch (error) {
      console.error("Error fetching categories:", error);
      res.status(500).json({ message: "Erreur lors de la récupération des catégories" });
    }
  });

  apiRouter.get("/categories/:slug", async (req, res) => {
    try {
      const category = await storage.getCategoryBySlug(req.params.slug);
      if (!category) {
        return res.status(404).json({ message: "Catégorie non trouvée" });
      }
      res.json(category);
    } catch (error) {
      console.error("Error fetching category:", error);
      res.status(500).json({ message: "Erreur lors de la récupération de la catégorie" });
    }
  });

  // Products
  apiRouter.get("/products", async (req, res) => {
    try {
      const categoryId = req.query.categoryId ? Number(req.query.categoryId) : undefined;
      const featured = req.query.featured === "true" ? true : undefined;
      const limit = req.query.limit ? Number(req.query.limit) : undefined;
      
      const products = await storage.getProducts({ categoryId, featured, limit });
      res.json(products);
    } catch (error) {
      console.error("Error fetching products:", error);
      res.status(500).json({ message: "Erreur lors de la récupération des produits" });
    }
  });

  apiRouter.get("/products/search", async (req, res) => {
    try {
      const query = req.query.q as string;
      if (!query) {
        return res.status(400).json({ message: "Terme de recherche requis" });
      }
      
      const products = await storage.searchProducts(query);
      res.json(products);
    } catch (error) {
      console.error("Error searching products:", error);
      res.status(500).json({ message: "Erreur lors de la recherche de produits" });
    }
  });

  apiRouter.get("/products/:slug", async (req, res) => {
    try {
      const product = await storage.getProductBySlug(req.params.slug);
      if (!product) {
        return res.status(404).json({ message: "Produit non trouvé" });
      }
      
      // Get the category for this product
      const category = await storage.getCategory(product.categoryId);
      
      res.json({ 
        ...product, 
        category 
      });
    } catch (error) {
      console.error("Error fetching product:", error);
      res.status(500).json({ message: "Erreur lors de la récupération du produit" });
    }
  });

  // Cart
  apiRouter.get("/cart", async (req, res) => {
    try {
      // Use session ID from cookies or create a new one
      let sessionId = req.cookies?.sessionId;
      if (!sessionId) {
        sessionId = uuidv4();
        res.cookie("sessionId", sessionId, { maxAge: 30 * 24 * 60 * 60 * 1000, httpOnly: true });
      }
      
      const cartItems = await storage.getCartItems(sessionId);
      res.json(cartItems);
    } catch (error) {
      console.error("Error fetching cart:", error);
      res.status(500).json({ message: "Erreur lors de la récupération du panier" });
    }
  });

  apiRouter.post("/cart", async (req, res) => {
    try {
      // Use session ID from cookies or create a new one
      let sessionId = req.cookies?.sessionId;
      if (!sessionId) {
        sessionId = uuidv4();
        res.cookie("sessionId", sessionId, { maxAge: 30 * 24 * 60 * 60 * 1000, httpOnly: true });
      }
      
      const cartItemData = insertCartItemSchema.parse({
        ...req.body,
        sessionId
      });
      
      // Check if the product exists
      const product = await storage.getProduct(cartItemData.productId);
      if (!product) {
        return res.status(404).json({ message: "Produit non trouvé" });
      }
      
      // Check if the item is already in the cart
      const existingCartItem = await storage.getCartItemByProductAndSession(
        cartItemData.productId, 
        sessionId
      );
      
      if (existingCartItem) {
        // Update quantity instead of creating a new item
        const updatedCartItem = await storage.updateCartItem(
          existingCartItem.id, 
          existingCartItem.quantity + cartItemData.quantity
        );
        return res.json(updatedCartItem);
      }
      
      const cartItem = await storage.createCartItem(cartItemData);
      res.status(201).json(cartItem);
    } catch (error) {
      console.error("Error adding to cart:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Données invalides", errors: error.errors });
      }
      res.status(500).json({ message: "Erreur lors de l'ajout au panier" });
    }
  });

  apiRouter.put("/cart/:id", async (req, res) => {
    try {
      const id = Number(req.params.id);
      const { quantity } = req.body;
      
      if (!quantity || quantity < 1) {
        return res.status(400).json({ message: "Quantité invalide" });
      }
      
      const cartItem = await storage.getCartItem(id);
      if (!cartItem) {
        return res.status(404).json({ message: "Article du panier non trouvé" });
      }
      
      // Ensure the cart item belongs to the current session
      const sessionId = req.cookies?.sessionId;
      if (!sessionId || cartItem.sessionId !== sessionId) {
        return res.status(403).json({ message: "Non autorisé" });
      }
      
      const updatedCartItem = await storage.updateCartItem(id, quantity);
      res.json(updatedCartItem);
    } catch (error) {
      console.error("Error updating cart item:", error);
      res.status(500).json({ message: "Erreur lors de la mise à jour de l'article" });
    }
  });

  apiRouter.delete("/cart/:id", async (req, res) => {
    try {
      const id = Number(req.params.id);
      
      const cartItem = await storage.getCartItem(id);
      if (!cartItem) {
        return res.status(404).json({ message: "Article du panier non trouvé" });
      }
      
      // Ensure the cart item belongs to the current session
      const sessionId = req.cookies?.sessionId;
      if (!sessionId || cartItem.sessionId !== sessionId) {
        return res.status(403).json({ message: "Non autorisé" });
      }
      
      await storage.deleteCartItem(id);
      res.status(204).end();
    } catch (error) {
      console.error("Error deleting cart item:", error);
      res.status(500).json({ message: "Erreur lors de la suppression de l'article" });
    }
  });

  apiRouter.delete("/cart", async (req, res) => {
    try {
      const sessionId = req.cookies?.sessionId;
      if (!sessionId) {
        return res.status(400).json({ message: "Session non trouvée" });
      }
      
      await storage.clearCart(sessionId);
      res.status(204).end();
    } catch (error) {
      console.error("Error clearing cart:", error);
      res.status(500).json({ message: "Erreur lors de la suppression du panier" });
    }
  });

  // Phone Verification
  apiRouter.post("/phone-verification/initiate", async (req: Request, res: Response) => {
    try {
      const { phoneNumber, userId } = req.body;
      
      if (!phoneNumber) {
        return res.status(400).json({ message: "Numéro de téléphone requis" });
      }
      
      // Generate a random 5-digit verification code
      const verificationCode = Math.floor(10000 + Math.random() * 90000).toString();
      
      // Create an expiration date (10 minutes from now)
      const expiresAt = new Date();
      expiresAt.setMinutes(expiresAt.getMinutes() + 10);
      
      // Create new verification entry
      const verification = await storage.createPhoneVerification({
        phoneNumber,
        userId: userId || null,
        verificationCode,
        expiresAt
      });
      
      // In a real app, would send this code via SMS
      // For this demo, just return it in the response
      // In production, only return success message
      res.status(201).json({ 
        message: "Code de vérification créé avec succès",
        verificationCode, // Remove in production, only for demo
        expiresAt
      });
    } catch (error) {
      console.error("Error initiating phone verification:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Données invalides", errors: error.errors });
      }
      res.status(500).json({ message: "Erreur lors de l'initiation de la vérification téléphonique" });
    }
  });
  
  apiRouter.post("/phone-verification/verify", async (req: Request, res: Response) => {
    try {
      const { userId, verificationCode } = req.body;
      
      if (!userId || !verificationCode) {
        return res.status(400).json({ message: "ID utilisateur et code de vérification requis" });
      }
      
      const success = await storage.verifyPhoneNumber(userId, verificationCode);
      
      if (!success) {
        return res.status(400).json({ message: "Code de vérification invalide ou expiré" });
      }
      
      // Get the updated user
      const user = await storage.getUser(userId);
      
      res.json({ 
        message: "Numéro de téléphone vérifié avec succès", 
        user 
      });
    } catch (error) {
      console.error("Error verifying phone:", error);
      res.status(500).json({ message: "Erreur lors de la vérification du numéro de téléphone" });
    }
  });
  
  apiRouter.post("/phone-verification/check-last-digits", async (req: Request, res: Response) => {
    try {
      const { phoneNumber, lastFiveDigits, userId } = req.body;
      
      if (!phoneNumber || !lastFiveDigits || !userId) {
        return res.status(400).json({ message: "Informations requises manquantes" });
      }
      
      // Check if the last 5 digits of the phone number match
      const lastFiveOfActualNumber = phoneNumber.slice(-5);
      
      if (lastFiveDigits !== lastFiveOfActualNumber) {
        return res.status(400).json({ message: "Les 5 derniers chiffres ne correspondent pas" });
      }
      
      // Update the user as verified
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "Utilisateur non trouvé" });
      }
      
      const updatedUser = await storage.updateUser(userId, {
        phoneNumber,
        isVerified: true
      });
      
      res.json({ 
        message: "Numéro de téléphone vérifié avec succès", 
        user: updatedUser 
      });
    } catch (error) {
      console.error("Error checking last digits:", error);
      res.status(500).json({ message: "Erreur lors de la vérification des derniers chiffres" });
    }
  });
  
  // Orders
  apiRouter.post("/orders", async (req, res) => {
    try {
      const sessionId = req.cookies?.sessionId;
      if (!sessionId) {
        return res.status(400).json({ message: "Session non trouvée" });
      }
      
      // Get cart items to create the order
      const cartItems = await storage.getCartItems(sessionId);
      if (cartItems.length === 0) {
        return res.status(400).json({ message: "Le panier est vide" });
      }
      
      // Calculate total
      const total = cartItems.reduce((sum, item) => {
        const price = item.product.discountPrice || item.product.price;
        return sum + (price * item.quantity);
      }, 0);
      
      // Create order
      const orderData = insertOrderSchema.parse({
        ...req.body,
        sessionId,
        total
      });
      
      const order = await storage.createOrder(orderData);
      
      // Create order items
      for (const cartItem of cartItems) {
        const price = cartItem.product.discountPrice || cartItem.product.price;
        await storage.createOrderItem({
          orderId: order.id,
          productId: cartItem.productId,
          quantity: cartItem.quantity,
          price
        });
      }
      
      // Clear the cart
      await storage.clearCart(sessionId);
      
      res.status(201).json(order);
    } catch (error) {
      console.error("Error creating order:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Données invalides", errors: error.errors });
      }
      res.status(500).json({ message: "Erreur lors de la création de la commande" });
    }
  });

  apiRouter.get("/orders", async (req, res) => {
    try {
      const sessionId = req.cookies?.sessionId;
      if (!sessionId) {
        return res.status(400).json({ message: "Session non trouvée" });
      }
      
      const orders = await storage.getOrders(undefined, sessionId);
      res.json(orders);
    } catch (error) {
      console.error("Error fetching orders:", error);
      res.status(500).json({ message: "Erreur lors de la récupération des commandes" });
    }
  });

  apiRouter.get("/orders/:id", async (req, res) => {
    try {
      const id = Number(req.params.id);
      
      const order = await storage.getOrder(id);
      if (!order) {
        return res.status(404).json({ message: "Commande non trouvée" });
      }
      
      // Ensure the order belongs to the current session
      const sessionId = req.cookies?.sessionId;
      if (!sessionId || order.sessionId !== sessionId) {
        return res.status(403).json({ message: "Non autorisé" });
      }
      
      // Get order items
      const orderItems = await storage.getOrderItems(id);
      
      res.json({
        ...order,
        items: orderItems
      });
    } catch (error) {
      console.error("Error fetching order:", error);
      res.status(500).json({ message: "Erreur lors de la récupération de la commande" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
