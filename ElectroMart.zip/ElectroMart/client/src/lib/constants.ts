export const CURRENCY = "FCFA";

export const NAVIGATION_LINKS = [
  { label: "Accueil", path: "/" },
  { label: "Catégories", path: "/categories", isDropdown: true },
  { label: "Meilleures offres", path: "/best-deals" },
  { label: "Nouveautés", path: "/new" },
  { label: "À propos", path: "/about" },
  { label: "Contact", path: "/contact" }
];

export const CATEGORIES = [
  { name: "Ordinateurs portables", slug: "ordinateurs-portables" },
  { name: "Smartphones", slug: "smartphones" },
  { name: "Tablettes", slug: "tablettes" },
  { name: "Accessoires", slug: "accessoires" },
  { name: "Audio", slug: "audio" }
];

export const CATEGORY_ICONS = {
  "ordinateurs-portables": "fa-laptop",
  "smartphones": "fa-mobile-alt",
  "tablettes": "fa-tablet-alt",
  "accessoires": "fa-keyboard",
  "audio": "fa-headphones"
};

export const PAYMENT_METHODS = [
  { name: "Carte bancaire", value: "card" },
  { name: "Orange Money", value: "orange-money" },
  { name: "MTN Mobile Money", value: "mtn-mobile-money" },
  { name: "Paiement à la livraison", value: "cash-on-delivery" }
];

export const COMPANY_INFO = {
  name: "TechMarket",
  address: "Abidjan, Cocody Angré 7ème tranche, Côte d'Ivoire",
  phone: "+225 07 0123 4567",
  email: "contact@techmarket.ci",
  hours: "Lun - Sam: 8h - 20h"
};

export const SOCIAL_LINKS = [
  { name: "Facebook", icon: "fab fa-facebook-f", url: "#" },
  { name: "Twitter", icon: "fab fa-twitter", url: "#" },
  { name: "Instagram", icon: "fab fa-instagram", url: "#" },
  { name: "WhatsApp", icon: "fab fa-whatsapp", url: "#" }
];

export const FOOTER_LINKS = {
  quick: [
    { label: "Accueil", path: "/" },
    { label: "À propos de nous", path: "/about" },
    { label: "Produits", path: "/products" },
    { label: "Promotions", path: "/best-deals" },
    { label: "Blog", path: "/blog" },
    { label: "Contact", path: "/contact" }
  ],
  categories: [
    { label: "Ordinateurs portables", path: "/categories/ordinateurs-portables" },
    { label: "Smartphones", path: "/categories/smartphones" },
    { label: "Tablettes", path: "/categories/tablettes" },
    { label: "Accessoires", path: "/categories/accessoires" },
    { label: "Audio", path: "/categories/audio" },
    { label: "TV & Moniteurs", path: "/categories/tv-moniteurs" }
  ]
};
