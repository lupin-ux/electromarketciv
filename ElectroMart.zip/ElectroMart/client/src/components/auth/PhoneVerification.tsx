import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/context/AuthContext';
import { useMutation } from '@tanstack/react-query';

// Formulaire de vérification par code
const codeVerificationSchema = z.object({
  verificationCode: z.string().length(5, { message: 'Le code doit contenir 5 chiffres' }),
});

// Formulaire de vérification par les 5 derniers chiffres
const lastDigitsSchema = z.object({
  phoneNumber: z.string().min(8, { message: 'Le numéro de téléphone est requis' }),
  lastFiveDigits: z.string().length(5, { message: 'Veuillez entrer les 5 derniers chiffres' }),
});

type CodeVerificationFormData = z.infer<typeof codeVerificationSchema>;
type LastDigitsFormData = z.infer<typeof lastDigitsSchema>;

type VerificationMethod = 'code' | 'last-digits';

export function PhoneVerification() {
  const [method, setMethod] = useState<VerificationMethod>('code');
  const [verificationInitiated, setVerificationInitiated] = useState(false);
  const { toast } = useToast();
  const { user, refreshUser } = useAuth();
  
  // Formulaire pour la vérification par code
  const codeForm = useForm<CodeVerificationFormData>({
    resolver: zodResolver(codeVerificationSchema),
    defaultValues: {
      verificationCode: '',
    },
  });
  
  // Formulaire pour la vérification par les 5 derniers chiffres
  const lastDigitsForm = useForm<LastDigitsFormData>({
    resolver: zodResolver(lastDigitsSchema),
    defaultValues: {
      phoneNumber: '',
      lastFiveDigits: '',
    },
  });
  
  // Mutation pour initier la vérification
  const initiateMutation = useMutation({
    mutationFn: async (phoneNumber: string) => {
      if (!user) throw new Error("Utilisateur non connecté");
      const res = await apiRequest('POST', '/api/phone-verification/initiate', {
        phoneNumber,
        userId: user.id
      });
      return await res.json();
    },
    onSuccess: (data, phoneNumber) => {
      toast({
        title: 'Code envoyé',
        description: `Un code de vérification a été envoyé au ${phoneNumber}. Pour les besoins de démonstration, voici le code: ${data.verificationCode}`,
      });
      setVerificationInitiated(true);
    },
    onError: (error) => {
      console.error('Failed to initiate verification:', error);
      toast({
        title: 'Erreur',
        description: 'Impossible d\'initier la vérification. Veuillez réessayer.',
        variant: 'destructive',
      });
    }
  });
  
  // Mutation pour vérifier le code
  const verifyCodeMutation = useMutation({
    mutationFn: async (data: CodeVerificationFormData) => {
      if (!user) throw new Error("Utilisateur non connecté");
      return apiRequest('POST', '/api/phone-verification/verify', {
        userId: user.id,
        verificationCode: data.verificationCode,
      });
    },
    onSuccess: () => {
      toast({
        title: 'Vérification réussie',
        description: 'Votre numéro de téléphone a été vérifié avec succès.',
      });
      refreshUser();
    },
    onError: (error) => {
      console.error('Failed to verify phone:', error);
      toast({
        title: 'Erreur',
        description: 'Code invalide ou expiré. Veuillez réessayer.',
        variant: 'destructive',
      });
    }
  });
  
  // Mutation pour vérifier les derniers chiffres
  const verifyLastDigitsMutation = useMutation({
    mutationFn: async (data: LastDigitsFormData) => {
      if (!user) throw new Error("Utilisateur non connecté");
      return apiRequest('POST', '/api/phone-verification/check-last-digits', {
        userId: user.id,
        phoneNumber: data.phoneNumber,
        lastFiveDigits: data.lastFiveDigits,
      });
    },
    onSuccess: () => {
      toast({
        title: 'Vérification réussie',
        description: 'Votre numéro de téléphone a été vérifié avec succès.',
      });
      refreshUser();
    },
    onError: (error) => {
      console.error('Failed to verify last digits:', error);
      toast({
        title: 'Erreur',
        description: 'Les 5 derniers chiffres ne correspondent pas. Veuillez réessayer.',
        variant: 'destructive',
      });
    }
  });
  
  // Fonctions qui utilisent les mutations
  const initiateVerification = (phoneNumber: string) => {
    initiateMutation.mutate(phoneNumber);
  };
  
  const onCodeSubmit = (data: CodeVerificationFormData) => {
    verifyCodeMutation.mutate(data);
  };
  
  const onLastDigitsSubmit = (data: LastDigitsFormData) => {
    verifyLastDigitsMutation.mutate(data);
  };
  
  if (!user) {
    return (
      <div className="p-4 bg-yellow-50 rounded-md">
        <p className="text-yellow-700">Veuillez vous connecter pour vérifier votre numéro de téléphone.</p>
      </div>
    );
  }
  
  if (user.isVerified) {
    return (
      <div className="p-4 bg-green-50 rounded-md">
        <p className="text-green-700">Votre numéro de téléphone ({user.phoneNumber}) est vérifié ✓</p>
      </div>
    );
  }
  
  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <h2 className="text-2xl font-bold mb-6">Vérification du numéro de téléphone</h2>
      
      <div className="flex space-x-4 mb-6">
        <button
          onClick={() => setMethod('code')}
          className={`px-4 py-2 rounded-md ${method === 'code' ? 'bg-primary text-white' : 'bg-gray-100'}`}
        >
          Par code de vérification
        </button>
        <button
          onClick={() => setMethod('last-digits')}
          className={`px-4 py-2 rounded-md ${method === 'last-digits' ? 'bg-primary text-white' : 'bg-gray-100'}`}
        >
          Par les 5 derniers chiffres
        </button>
      </div>
      
      {method === 'code' && (
        <div>
          {!verificationInitiated ? (
            <div className="space-y-4">
              <p className="text-gray-600 mb-4">
                Nous vous enverrons un code de vérification par SMS pour confirmer votre numéro.
              </p>
              <div className="flex space-x-2">
                <input
                  type="tel"
                  placeholder="Votre numéro de téléphone"
                  className="flex-1 px-4 py-2 border rounded-md"
                  onChange={(e) => lastDigitsForm.setValue('phoneNumber', e.target.value)}
                />
                <button
                  onClick={() => initiateVerification(lastDigitsForm.getValues().phoneNumber)}
                  disabled={initiateMutation.isPending || !lastDigitsForm.getValues().phoneNumber}
                  className="px-4 py-2 bg-primary text-white rounded-md disabled:opacity-50"
                >
                  {initiateMutation.isPending ? 'Envoi...' : 'Envoyer le code'}
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={codeForm.handleSubmit(onCodeSubmit)} className="space-y-4">
              <p className="text-gray-600 mb-4">
                Veuillez entrer le code à 5 chiffres que vous avez reçu par SMS.
              </p>
              <div>
                <input
                  type="text"
                  placeholder="Code à 5 chiffres"
                  {...codeForm.register('verificationCode')}
                  className="w-full px-4 py-2 border rounded-md"
                  maxLength={5}
                />
                {codeForm.formState.errors.verificationCode && (
                  <p className="text-red-500 text-sm mt-1">
                    {codeForm.formState.errors.verificationCode.message}
                  </p>
                )}
              </div>
              <button
                type="submit"
                disabled={verifyCodeMutation.isPending}
                className="w-full px-4 py-2 bg-primary text-white rounded-md disabled:opacity-50"
              >
                {verifyCodeMutation.isPending ? 'Vérification...' : 'Vérifier le code'}
              </button>
            </form>
          )}
        </div>
      )}
      
      {method === 'last-digits' && (
        <form onSubmit={lastDigitsForm.handleSubmit(onLastDigitsSubmit)} className="space-y-4">
          <p className="text-gray-600 mb-4">
            Appelez notre numéro au <strong>+225 07 XX XX XX</strong> depuis votre téléphone, 
            puis entrez les 5 derniers chiffres de votre numéro ci-dessous.
          </p>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Votre numéro de téléphone
            </label>
            <input
              type="tel"
              placeholder="Exemple: 0709XX5678"
              {...lastDigitsForm.register('phoneNumber')}
              className="w-full px-4 py-2 border rounded-md"
            />
            {lastDigitsForm.formState.errors.phoneNumber && (
              <p className="text-red-500 text-sm mt-1">
                {lastDigitsForm.formState.errors.phoneNumber.message}
              </p>
            )}
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Les 5 derniers chiffres de votre numéro
            </label>
            <input
              type="text"
              placeholder="Les 5 derniers chiffres"
              {...lastDigitsForm.register('lastFiveDigits')}
              className="w-full px-4 py-2 border rounded-md"
              maxLength={5}
            />
            {lastDigitsForm.formState.errors.lastFiveDigits && (
              <p className="text-red-500 text-sm mt-1">
                {lastDigitsForm.formState.errors.lastFiveDigits.message}
              </p>
            )}
          </div>
          <button
            type="submit"
            disabled={verifyLastDigitsMutation.isPending}
            className="w-full px-4 py-2 bg-primary text-white rounded-md disabled:opacity-50"
          >
            {verifyLastDigitsMutation.isPending ? 'Vérification...' : 'Vérifier mon numéro'}
          </button>
        </form>
      )}
    </div>
  );
}