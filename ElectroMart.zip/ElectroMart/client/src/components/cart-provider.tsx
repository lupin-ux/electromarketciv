import { createContext, useContext, useEffect, useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useQueryClient } from "@tanstack/react-query";

// Types for cart functionality
type CartItem = {
  id: number;
  productId: number;
  quantity: number;
  sessionId?: string;
  userId?: number;
  product: {
    id: number;
    name: string;
    price: number;
    discountPrice?: number;
    imageUrl: string;
    slug: string;
  };
};

type CartContextType = {
  items: CartItem[];
  isLoading: boolean;
  addToCart: (productId: number, quantity?: number) => Promise<void>;
  removeFromCart: (itemId: number) => Promise<void>;
  updateQuantity: (itemId: number, quantity: number) => Promise<void>;
  clearCart: () => Promise<void>;
  totalItems: number;
  totalPrice: number;
};

// Create the context
const CartContext = createContext<CartContextType | undefined>(undefined);

// Generate a persistent session ID for guests
const getSessionId = () => {
  let sessionId = localStorage.getItem("cart_session_id");
  if (!sessionId) {
    sessionId = Math.random().toString(36).substring(2, 15);
    localStorage.setItem("cart_session_id", sessionId);
  }
  return sessionId;
};

// Provider component
export function CartProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const sessionId = getSessionId();

  // Calculate totals
  const totalItems = items.reduce((total, item) => total + item.quantity, 0);
  const totalPrice = items.reduce((total, item) => {
    const price = item.product.discountPrice || item.product.price;
    return total + price * item.quantity;
  }, 0);

  // Fetch cart items on component mount
  useEffect(() => {
    fetchCartItems();
  }, []);

  const fetchCartItems = async () => {
    try {
      setIsLoading(true);
      const response = await fetch(`/api/cart?sessionId=${sessionId}`);
      
      if (!response.ok) {
        throw new Error("Failed to fetch cart items");
      }
      
      const data = await response.json();
      setItems(data);
    } catch (error) {
      console.error("Error fetching cart:", error);
      toast({
        title: "Erreur",
        description: "Impossible de charger votre panier",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const addToCart = async (productId: number, quantity = 1) => {
    try {
      setIsLoading(true);
      const response = await apiRequest("POST", "/api/cart", {
        productId,
        quantity,
        sessionId,
      });
      
      const newItem = await response.json();
      
      // Check if the item already exists in the cart
      const existingItemIndex = items.findIndex(item => item.productId === productId);
      
      if (existingItemIndex !== -1) {
        // Update the existing item
        const updatedItems = [...items];
        updatedItems[existingItemIndex] = newItem;
        setItems(updatedItems);
      } else {
        // Add as a new item
        setItems([...items, newItem]);
      }
      
      toast({
        title: "Produit ajouté",
        description: "Le produit a été ajouté à votre panier",
      });
      
      // Invalidate relevant queries
      queryClient.invalidateQueries({ queryKey: ["/api/cart"] });
    } catch (error) {
      console.error("Error adding to cart:", error);
      toast({
        title: "Erreur",
        description: "Impossible d'ajouter le produit au panier",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const removeFromCart = async (itemId: number) => {
    try {
      setIsLoading(true);
      await apiRequest("DELETE", `/api/cart/${itemId}`, undefined);
      
      setItems(items.filter((item) => item.id !== itemId));
      
      toast({
        title: "Produit retiré",
        description: "Le produit a été retiré de votre panier",
      });
      
      // Invalidate relevant queries
      queryClient.invalidateQueries({ queryKey: ["/api/cart"] });
    } catch (error) {
      console.error("Error removing from cart:", error);
      toast({
        title: "Erreur",
        description: "Impossible de retirer le produit du panier",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const updateQuantity = async (itemId: number, quantity: number) => {
    try {
      if (quantity < 1) {
        return removeFromCart(itemId);
      }
      
      setIsLoading(true);
      const response = await apiRequest("PATCH", `/api/cart/${itemId}`, {
        quantity,
      });
      
      const updatedItem = await response.json();
      
      setItems(
        items.map((item) => (item.id === itemId ? updatedItem : item))
      );
      
      // Invalidate relevant queries
      queryClient.invalidateQueries({ queryKey: ["/api/cart"] });
    } catch (error) {
      console.error("Error updating cart:", error);
      toast({
        title: "Erreur",
        description: "Impossible de mettre à jour la quantité",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const clearCart = async () => {
    try {
      setIsLoading(true);
      await apiRequest("DELETE", `/api/cart?sessionId=${sessionId}`, undefined);
      
      setItems([]);
      
      toast({
        title: "Panier vidé",
        description: "Votre panier a été vidé avec succès",
      });
      
      // Invalidate relevant queries
      queryClient.invalidateQueries({ queryKey: ["/api/cart"] });
    } catch (error) {
      console.error("Error clearing cart:", error);
      toast({
        title: "Erreur",
        description: "Impossible de vider votre panier",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <CartContext.Provider
      value={{
        items,
        isLoading,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        totalItems,
        totalPrice,
      }}
    >
      {children}
    </CartContext.Provider>
  );
}

// Custom hook to use the cart context
export const useCart = () => {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error("useCart must be used within a CartProvider");
  }
  return context;
};
