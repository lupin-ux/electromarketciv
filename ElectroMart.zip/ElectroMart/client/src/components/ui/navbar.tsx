import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useTranslation } from "react-i18next";
import { 
  Phone,
  Mail,
  User,
  Globe,
  Search,
  Menu,
  ShoppingCart,
  ChevronDown
} from "lucide-react";
import { useCart } from "../cart-provider";
import { Button } from "./button";
import { Input } from "./input";
import { useQuery } from "@tanstack/react-query";
import { useMobile } from "@/hooks/use-mobile";

interface Category {
  id: number;
  name: string;
  slug: string;
}

export function Navbar() {
  const { t } = useTranslation();
  const [location, setLocation] = useLocation();
  const { totalItems } = useCart();
  const isMobile = useMobile();
  
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  
  // Fetch categories
  const { data: categories } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });
  
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setLocation(`/products?search=${encodeURIComponent(searchQuery)}`);
    }
  };
  
  const handleMobileMenuToggle = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  return (
    <header className="bg-white shadow-sm">
      <div className="container mx-auto px-4">
        {/* Top Bar */}
        <div className="flex items-center justify-between py-3 border-b border-gray-200">
          <div className="flex items-center space-x-4">
            <a href="tel:+22512345678" className="text-sm text-gray-600 hover:text-primary-600">
              <Phone size={16} className="inline mr-2" />
              +225 12 34 56 78
            </a>
            <a href="mailto:contact@techstore.ci" className="text-sm text-gray-600 hover:text-primary-600 hidden sm:inline-flex">
              <Mail size={16} className="inline mr-2" />
              contact@techstore.ci
            </a>
          </div>
          <div className="flex items-center space-x-4">
            <a href="#" className="text-sm text-gray-600 hover:text-primary-600">
              <User size={16} className="inline mr-1" />
              <span className="hidden sm:inline">{t('header.myAccount')}</span>
            </a>
            <div className="relative">
              <button className="text-sm text-gray-600 hover:text-primary-600 flex items-center">
                <Globe size={16} className="inline mr-1" />
                <span>FR</span>
                <ChevronDown size={12} className="ml-1" />
              </button>
            </div>
          </div>
        </div>
        
        {/* Main Navigation */}
        <div className="flex items-center justify-between py-4">
          {/* Logo */}
          <Link href="/" className="flex items-center">
            <span className="text-2xl font-bold">
              <span className="text-primary-600">Tech</span>
              <span className="text-amber-500">Store</span>
            </span>
          </Link>
          
          {/* Search Bar */}
          <div className="hidden md:flex flex-1 max-w-xl px-4">
            <form onSubmit={handleSearch} className="relative w-full">
              <Input 
                type="text" 
                placeholder={t('header.search')}
                className="w-full py-2 px-4 bg-gray-100 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 focus:bg-white"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <Button 
                type="submit"
                variant="ghost"
                className="absolute right-0 top-0 h-full px-4 text-gray-500 hover:text-primary-600"
              >
                <Search size={20} />
              </Button>
            </form>
          </div>
          
          {/* Cart and Mobile Menu */}
          <div className="flex items-center space-x-4">
            <Link href="/cart" className="relative p-2">
              <ShoppingCart size={20} />
              {totalItems > 0 && (
                <span className="absolute -top-1 -right-1 bg-amber-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs">
                  {totalItems}
                </span>
              )}
            </Link>
            <Button 
              variant="ghost" 
              className="md:hidden p-2"
              onClick={handleMobileMenuToggle}
            >
              <Menu size={20} />
            </Button>
          </div>
        </div>
        
        {/* Category Navigation */}
        <nav className="hidden md:block py-3 border-t border-gray-200">
          <ul className="flex space-x-6">
            {categories?.map((category) => (
              <li key={category.id}>
                <Link 
                  href={`/products?category=${category.slug}`}
                  className="text-sm font-medium hover:text-primary-600"
                >
                  {category.name}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
        
        {/* Mobile Search - Only visible on mobile */}
        <div className="md:hidden py-3">
          <form onSubmit={handleSearch} className="relative w-full">
            <Input 
              type="text" 
              placeholder={t('header.search')}
              className="w-full py-2 px-4 bg-gray-100 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 focus:bg-white"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <Button 
              type="submit"
              variant="ghost"
              className="absolute right-0 top-0 h-full px-4 text-gray-500 hover:text-primary-600"
            >
              <Search size={20} />
            </Button>
          </form>
        </div>
        
        {/* Mobile Menu - Hidden by default */}
        {mobileMenuOpen && (
          <div className="md:hidden py-4 border-t border-gray-200">
            <ul className="space-y-3">
              {categories?.map((category) => (
                <li key={category.id}>
                  <Link 
                    href={`/products?category=${category.slug}`}
                    className="block text-sm font-medium hover:text-primary-600"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    {category.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </header>
  );
}
