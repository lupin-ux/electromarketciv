import { useTranslation } from "react-i18next";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";

export function Footer() {
  const { t } = useTranslation();
  
  // Fetch categories for footer
  const { data: categories } = useQuery({
    queryKey: ["/api/categories"],
  });

  return (
    <footer className="bg-gray-900 text-white pt-12 pb-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-10">
          <div>
            <h3 className="text-xl font-bold mb-4">{t('footer.about.title')}</h3>
            <p className="text-gray-400 mb-4">{t('footer.about.description')}</p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white">
                <i className="fab fa-facebook-f"></i>
              </a>
              <a href="#" className="text-gray-400 hover:text-white">
                <i className="fab fa-twitter"></i>
              </a>
              <a href="#" className="text-gray-400 hover:text-white">
                <i className="fab fa-instagram"></i>
              </a>
              <a href="#" className="text-gray-400 hover:text-white">
                <i className="fab fa-whatsapp"></i>
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-xl font-bold mb-4">{t('footer.quickLinks.title')}</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="text-gray-400 hover:text-white">
                  {t('footer.quickLinks.home')}
                </Link>
              </li>
              <li>
                <Link href="/products" className="text-gray-400 hover:text-white">
                  {t('footer.quickLinks.products')}
                </Link>
              </li>
              <li>
                <Link href="#" className="text-gray-400 hover:text-white">
                  {t('footer.quickLinks.about')}
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-gray-400 hover:text-white">
                  {t('footer.quickLinks.contact')}
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-xl font-bold mb-4">{t('footer.categories.title')}</h3>
            <ul className="space-y-2">
              {categories?.slice(0, 5).map((category) => (
                <li key={category.id}>
                  <Link 
                    href={`/products?category=${category.slug}`} 
                    className="text-gray-400 hover:text-white"
                  >
                    {category.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          
          <div>
            <h3 className="text-xl font-bold mb-4">{t('footer.customerService.title')}</h3>
            <ul className="space-y-2">
              <li>
                <Link href="#" className="text-gray-400 hover:text-white">
                  {t('footer.customerService.faq')}
                </Link>
              </li>
              <li>
                <Link href="#" className="text-gray-400 hover:text-white">
                  {t('footer.customerService.delivery')}
                </Link>
              </li>
              <li>
                <Link href="#" className="text-gray-400 hover:text-white">
                  {t('footer.customerService.returns')}
                </Link>
              </li>
              <li>
                <Link href="#" className="text-gray-400 hover:text-white">
                  {t('footer.customerService.terms')}
                </Link>
              </li>
              <li>
                <Link href="#" className="text-gray-400 hover:text-white">
                  {t('footer.customerService.privacy')}
                </Link>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="pt-6 border-t border-gray-800 text-center">
          <p className="text-gray-500">{t('footer.copyright')}</p>
        </div>
      </div>
    </footer>
  );
}
