import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useTranslation } from "react-i18next";
import { useCart } from "./cart-provider";
import { Badge } from "./ui/badge";
import { ShoppingCart } from "lucide-react";
import { Link } from "wouter";

interface ProductCardProps {
  product: {
    id: number;
    name: string;
    slug: string;
    description?: string;
    price: number;
    discountPrice?: number;
    stock: number;
    categoryId: number;
    imageUrl: string;
    rating?: number;
    reviewCount?: number;
    featured?: boolean;
    isNewArrival?: boolean;
  };
}

export function ProductCard({ product }: ProductCardProps) {
  const { t } = useTranslation();
  const { addToCart } = useCart();

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart(product.id);
  };

  // Generate rating stars
  const renderRatingStars = () => {
    if (!product.rating) return null;
    
    const stars = [];
    const fullStars = Math.floor(product.rating);
    const halfStar = product.rating % 1 >= 0.5;
    
    // Full stars
    for (let i = 0; i < fullStars; i++) {
      stars.push(<i key={`star-${i}`} className="fas fa-star"></i>);
    }
    
    // Half star if needed
    if (halfStar) {
      stars.push(<i key="half-star" className="fas fa-star-half-alt"></i>);
    }
    
    // Empty stars to make 5 total
    const emptyStars = 5 - fullStars - (halfStar ? 1 : 0);
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<i key={`empty-${i}`} className="far fa-star"></i>);
    }
    
    return (
      <div className="flex items-center text-amber-500">
        {stars}
        {product.reviewCount && (
          <span className="text-gray-500 text-sm ml-1">({product.reviewCount})</span>
        )}
      </div>
    );
  };

  return (
    <Card className="overflow-hidden transition-all duration-200 hover:-translate-y-1 hover:shadow-md">
      <Link href={`/products/${product.slug}`} className="block">
        <div className="relative">
          <img 
            src={product.imageUrl} 
            alt={product.name}
            className="w-full h-48 object-cover"
          />
          {product.isNewArrival && (
            <Badge className="absolute top-2 left-2 bg-amber-500 hover:bg-amber-600">
              {t('home.featuredProducts.new')}
            </Badge>
          )}
          {product.discountPrice && (
            <Badge className="absolute top-2 left-2 bg-primary-600 hover:bg-primary-700">
              {t('home.featuredProducts.discount')}
            </Badge>
          )}
        </div>
        <CardContent className="p-4">
          <h3 className="text-lg font-semibold">{product.name}</h3>
          <p className="text-gray-600 text-sm mt-1">{product.description}</p>
          
          {product.rating && (
            <div className="mt-3 mb-2">
              {renderRatingStars()}
            </div>
          )}
          
          <div className="flex justify-between items-center mt-4">
            <div className="font-bold text-lg">
              {product.discountPrice ? (
                <>
                  {new Intl.NumberFormat('fr-CI').format(product.discountPrice)} <span className="text-sm">{t('common.currency')}</span>
                  <span className="text-gray-500 line-through text-sm ml-1">
                    {new Intl.NumberFormat('fr-CI').format(product.price)}
                  </span>
                </>
              ) : (
                <>
                  {new Intl.NumberFormat('fr-CI').format(product.price)} <span className="text-sm">{t('common.currency')}</span>
                </>
              )}
            </div>
            <Button 
              size="sm" 
              onClick={handleAddToCart}
              className="bg-primary-600 hover:bg-primary-700 text-white"
            >
              <ShoppingCart className="h-4 w-4 mr-1" />
              {t('home.featuredProducts.addToCart')}
            </Button>
          </div>
        </CardContent>
      </Link>
    </Card>
  );
}
