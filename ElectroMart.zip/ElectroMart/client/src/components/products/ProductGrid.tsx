import { useState } from "react";
import { useTranslation } from "react-i18next";
import { Product } from "@shared/schema";
import ProductCard from "./ProductCard";

type ProductGridProps = {
  products: Product[];
  isLoading?: boolean;
  error?: any;
  title?: string;
  showFilters?: boolean;
};

const ProductGrid = ({ 
  products, 
  isLoading = false, 
  error = null, 
  title, 
  showFilters = false 
}: ProductGridProps) => {
  const { t } = useTranslation();
  const [filterCategory, setFilterCategory] = useState("all");
  const [sortBy, setSortBy] = useState("popularity");
  const [viewType, setViewType] = useState("grid");

  const filteredProducts = filterCategory === "all" 
    ? products 
    : products.filter(product => product.categoryId.toString() === filterCategory);

  const sortedProducts = [...filteredProducts].sort((a, b) => {
    switch (sortBy) {
      case "price-asc":
        return (a.discountPrice || a.price) - (b.discountPrice || b.price);
      case "price-desc":
        return (b.discountPrice || b.price) - (a.discountPrice || a.price);
      case "newest":
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      case "popularity":
      default:
        return b.rating - a.rating;
    }
  });

  if (isLoading) {
    return (
      <div className="flex justify-center items-center py-12">
        <div className="loader h-12 w-12 rounded-full border-4 border-neutral-200 border-t-primary animate-spin"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-12">
        <p className="text-error mb-4">{t("common.error")}</p>
        <button 
          className="bg-primary text-white px-4 py-2 rounded-lg"
          onClick={() => window.location.reload()}
        >
          {t("common.retry")}
        </button>
      </div>
    );
  }

  return (
    <div>
      {title && (
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-2xl md:text-3xl font-poppins font-semibold text-secondary">{title}</h2>
          <div className="hidden md:flex items-center">
            <button className="px-3 py-1 border border-neutral-300 rounded-l-lg hover:bg-neutral-200">
              <i className="fas fa-chevron-left"></i>
            </button>
            <button className="px-3 py-1 border border-neutral-300 rounded-r-lg hover:bg-neutral-200 border-l-0">
              <i className="fas fa-chevron-right"></i>
            </button>
          </div>
        </div>
      )}

      {showFilters && (
        <div className="mb-6 bg-white p-4 rounded-lg shadow-sm">
          <div className="flex flex-wrap items-center justify-between">
            <div className="mb-2 md:mb-0 w-full md:w-auto flex items-center">
              <span className="text-sm text-neutral-500 mr-2">{t("home.featuredProducts.filterBy")}</span>
              <select 
                className="text-sm border border-neutral-300 rounded p-1 focus:outline-none focus:ring-1 focus:ring-primary"
                value={filterCategory}
                onChange={(e) => setFilterCategory(e.target.value)}
              >
                <option value="all">{t("home.featuredProducts.allProducts")}</option>
                <option value="1">{t("home.featuredProducts.laptops")}</option>
                <option value="2">{t("home.featuredProducts.smartphones")}</option>
                <option value="3">{t("home.featuredProducts.tablets")}</option>
                <option value="5">{t("home.featuredProducts.accessories")}</option>
              </select>
            </div>
            
            <div className="mb-2 md:mb-0 w-full md:w-auto flex items-center">
              <span className="text-sm text-neutral-500 mr-2">{t("home.featuredProducts.sortBy")}</span>
              <select 
                className="text-sm border border-neutral-300 rounded p-1 focus:outline-none focus:ring-1 focus:ring-primary"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
              >
                <option value="popularity">{t("home.featuredProducts.popularity")}</option>
                <option value="price-asc">{t("home.featuredProducts.priceAsc")}</option>
                <option value="price-desc">{t("home.featuredProducts.priceDesc")}</option>
                <option value="newest">{t("home.featuredProducts.newest")}</option>
              </select>
            </div>
            
            <div className="w-full md:w-auto flex items-center">
              <span className="text-sm text-neutral-500 mr-2">{t("home.featuredProducts.show")}</span>
              <div className="flex">
                <button 
                  className={`${viewType === 'grid' ? 'bg-primary text-white' : 'bg-white text-neutral-700 border border-neutral-300'} h-8 w-8 flex items-center justify-center rounded-l`}
                  onClick={() => setViewType('grid')}
                >
                  <i className="fas fa-grip-horizontal"></i>
                </button>
                <button 
                  className={`${viewType === 'list' ? 'bg-primary text-white' : 'bg-white text-neutral-700 border border-neutral-300'} h-8 w-8 flex items-center justify-center rounded-r border-l-0`}
                  onClick={() => setViewType('list')}
                >
                  <i className="fas fa-list"></i>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {sortedProducts.length === 0 ? (
        <div className="text-center py-12">
          <i className="fas fa-box-open text-neutral-300 text-5xl mb-4"></i>
          <p className="text-neutral-500">{t("products.noProducts")}</p>
        </div>
      ) : (
        <div className={viewType === 'grid' ? "grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6" : "space-y-4"}>
          {sortedProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      )}
    </div>
  );
};

export default ProductGrid;
