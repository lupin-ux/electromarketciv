import { useState } from "react";
import { useTranslation } from "react-i18next";
import { Product, Category } from "@shared/schema";
import { useCart } from "@/hooks/useCart";
import { CURRENCY } from "@/lib/constants";
import { formatPrice } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

type ProductDetailProps = {
  product: Product & { category?: Category };
  relatedProducts?: Product[];
  isLoading?: boolean;
};

const ProductDetail = ({ product, relatedProducts = [], isLoading = false }: ProductDetailProps) => {
  const { t } = useTranslation();
  const { addToCart } = useCart();
  const [quantity, setQuantity] = useState(1);

  if (isLoading) {
    return (
      <div className="flex justify-center items-center py-12">
        <div className="loader h-12 w-12 rounded-full border-4 border-neutral-200 border-t-primary animate-spin"></div>
      </div>
    );
  }

  const handleAddToCart = () => {
    addToCart(product.id, quantity);
  };

  const discountPercentage = product.discountPrice 
    ? Math.round((1 - product.discountPrice / product.price) * 100) 
    : 0;

  return (
    <div className="bg-white rounded-lg shadow-sm overflow-hidden p-4 md:p-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Product Image */}
        <div className="relative">
          <img 
            src={product.imageUrl}
            alt={product.name}
            className="w-full h-auto rounded-lg object-contain"
            loading="lazy"
          />
          {product.isNew && (
            <div className="absolute top-4 right-4 bg-success text-white text-xs font-semibold px-3 py-1 rounded">
              {t("products.new")}
            </div>
          )}
          {product.discountPrice && (
            <div className="absolute top-4 left-4 bg-error text-white text-xs font-semibold px-3 py-1 rounded">
              {t("products.sale", { percent: discountPercentage })}
            </div>
          )}
        </div>

        {/* Product Info */}
        <div>
          <div className="mb-2 flex items-center">
            <span className="text-sm text-neutral-500 mr-2">
              {product.category?.name || "Produit"}
            </span>
            <div className="flex text-warning">
              {[...Array(5)].map((_, index) => {
                const starValue = index + 1;
                return (
                  <i 
                    key={index} 
                    className={`${
                      starValue <= Math.floor(product.rating)
                        ? "fas fa-star"
                        : starValue <= product.rating + 0.5
                        ? "fas fa-star-half-alt"
                        : "far fa-star"
                    } text-sm`}
                  ></i>
                );
              })}
              <span className="text-xs text-neutral-500 ml-1">
                ({product.reviewCount})
              </span>
            </div>
          </div>

          <h1 className="text-2xl md:text-3xl font-poppins font-bold text-neutral-800 mb-4">
            {product.name}
          </h1>

          <div className="flex items-center mb-6">
            <p className="text-2xl font-bold text-primary">
              {formatPrice(product.discountPrice || product.price)} <span className="text-sm">{CURRENCY}</span>
            </p>
            {product.discountPrice && (
              <p className="text-neutral-500 line-through text-lg ml-3">
                {formatPrice(product.price)} {CURRENCY}
              </p>
            )}
          </div>

          <p className="text-neutral-600 mb-6">
            {product.description}
          </p>

          {/* Add to Cart */}
          <div className="flex items-center mb-6">
            <div className="flex items-center border border-neutral-300 rounded-lg overflow-hidden mr-4">
              <button 
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                className="px-3 py-2 bg-neutral-100 hover:bg-neutral-200"
              >
                <i className="fas fa-minus"></i>
              </button>
              <span className="px-4 py-2">{quantity}</span>
              <button 
                onClick={() => setQuantity(quantity + 1)}
                className="px-3 py-2 bg-neutral-100 hover:bg-neutral-200"
              >
                <i className="fas fa-plus"></i>
              </button>
            </div>
            
            <Button
              onClick={handleAddToCart}
              className="bg-primary hover:bg-primary/90 text-white px-6 py-2 rounded-lg"
              disabled={!product.inStock}
            >
              {product.inStock ? (
                <>
                  <i className="fas fa-shopping-cart mr-2"></i>
                  {t("products.addToCart")}
                </>
              ) : (
                t("products.outOfStock")
              )}
            </Button>
            
            <button className="ml-3 w-10 h-10 border border-neutral-300 rounded-full flex items-center justify-center hover:bg-neutral-100">
              <i className="far fa-heart"></i>
            </button>
          </div>

          {/* Availability */}
          <div className="mb-6">
            <p className="flex items-center">
              <span className="text-neutral-600 mr-2">Disponibilité:</span>
              {product.inStock ? (
                <span className="text-success flex items-center">
                  <i className="fas fa-check-circle mr-1"></i> En stock
                </span>
              ) : (
                <span className="text-error flex items-center">
                  <i className="fas fa-times-circle mr-1"></i> Rupture de stock
                </span>
              )}
            </p>
          </div>

          {/* Specifications Preview */}
          {product.specifications && (
            <div className="bg-neutral-50 p-4 rounded-lg mb-6">
              <h3 className="font-semibold mb-2">Caractéristiques:</h3>
              <ul className="grid grid-cols-1 md:grid-cols-2 gap-2">
                {Object.entries(product.specifications as Record<string, string>).slice(0, 4).map(([key, value]) => (
                  <li key={key} className="flex items-start">
                    <i className="fas fa-check text-primary mt-1 mr-2"></i>
                    <span>
                      <span className="font-medium">{key}:</span> {value}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Share */}
          <div className="flex items-center">
            <span className="text-neutral-600 mr-3">Partager:</span>
            <div className="flex space-x-2">
              <a href="#" className="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center hover:bg-blue-700">
                <i className="fab fa-facebook-f"></i>
              </a>
              <a href="#" className="w-8 h-8 bg-blue-400 text-white rounded-full flex items-center justify-center hover:bg-blue-500">
                <i className="fab fa-twitter"></i>
              </a>
              <a href="#" className="w-8 h-8 bg-red-600 text-white rounded-full flex items-center justify-center hover:bg-red-700">
                <i className="fab fa-pinterest"></i>
              </a>
              <a href="#" className="w-8 h-8 bg-green-500 text-white rounded-full flex items-center justify-center hover:bg-green-600">
                <i className="fab fa-whatsapp"></i>
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Details Tabs */}
      <div className="mt-12">
        <Tabs defaultValue="description">
          <TabsList className="border-b border-neutral-200 mb-6">
            <TabsTrigger value="description" className="text-lg font-medium px-6 py-3">
              {t("products.description")}
            </TabsTrigger>
            <TabsTrigger value="specifications" className="text-lg font-medium px-6 py-3">
              {t("products.specifications")}
            </TabsTrigger>
            <TabsTrigger value="reviews" className="text-lg font-medium px-6 py-3">
              {t("products.reviews", { count: product.reviewCount })}
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="description" className="p-4">
            <div className="prose max-w-none">
              <p>{product.description}</p>
              {/* Add more description content here */}
            </div>
          </TabsContent>
          
          <TabsContent value="specifications" className="p-4">
            <div className="bg-white rounded-lg">
              {product.specifications ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {Object.entries(product.specifications as Record<string, string>).map(([key, value]) => (
                    <div key={key} className="flex border-b border-neutral-100 pb-3">
                      <span className="font-medium w-1/3">{key}:</span>
                      <span className="text-neutral-600 w-2/3">{value}</span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-neutral-500">Aucune spécification disponible pour ce produit.</p>
              )}
            </div>
          </TabsContent>
          
          <TabsContent value="reviews" className="p-4">
            <div className="bg-white rounded-lg">
              {product.reviewCount > 0 ? (
                <p>Avis clients disponibles.</p>
              ) : (
                <p className="text-neutral-500">Aucun avis client pour ce produit.</p>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default ProductDetail;
