import { useTranslation } from "react-i18next";
import { Link } from "wouter";
import { Product } from "@shared/schema";
import { useCart } from "@/hooks/useCart";
import { CURRENCY } from "@/lib/constants";
import { formatPrice } from "@/lib/utils";
import { Button } from "@/components/ui/button";

type ProductCardProps = {
  product: Product;
};

const ProductCard = ({ product }: ProductCardProps) => {
  const { t } = useTranslation();
  const { addToCart } = useCart();
  
  const discountPercentage = product.discountPrice 
    ? Math.round((1 - product.discountPrice / product.price) * 100) 
    : 0;

  return (
    <div className="bg-white rounded-lg shadow-sm overflow-hidden transition duration-300 hover:shadow-lg hover:-translate-y-1">
      <Link href={`/products/${product.slug}`}>
        <div className="relative">
          <img 
            src={product.imageUrl}
            alt={product.name}
            className="w-full h-48 object-cover"
            loading="lazy"
          />
          {product.isNew && (
            <div className="absolute top-2 right-2 bg-success text-white text-xs font-semibold px-2 py-1 rounded">
              {t("products.new")}
            </div>
          )}
          {product.discountPrice && (
            <div className="absolute top-2 right-2 bg-error text-white text-xs font-semibold px-2 py-1 rounded">
              {t("products.sale", { percent: discountPercentage })}
            </div>
          )}
          <button 
            className="absolute top-2 left-2 text-neutral-500 hover:text-primary bg-white rounded-full p-2 shadow-sm"
            aria-label="Add to wishlist"
          >
            <i className="far fa-heart"></i>
          </button>
        </div>
      </Link>
      
      <div className="p-4">
        <div className="text-xs text-neutral-500 mb-1">
          {product.categoryName || "Produit"}
        </div>
        
        <Link href={`/products/${product.slug}`}>
          <h3 className="font-semibold text-neutral-800 mb-2 hover:text-primary">
            {product.name}
          </h3>
        </Link>
        
        <div className="flex items-center mb-2">
          <div className="flex text-warning">
            {[...Array(5)].map((_, index) => {
              const starValue = index + 1;
              return (
                <i 
                  key={index} 
                  className={`${
                    starValue <= Math.floor(product.rating)
                      ? "fas fa-star"
                      : starValue <= product.rating + 0.5
                      ? "fas fa-star-half-alt"
                      : "far fa-star"
                  }`}
                ></i>
              );
            })}
          </div>
          <span className="text-xs text-neutral-500 ml-1">
            ({product.reviewCount})
          </span>
        </div>
        
        <div className="flex items-center justify-between mt-2">
          <div className="flex items-center">
            <p className="font-bold text-lg">
              {formatPrice(product.discountPrice || product.price)} <span className="text-xs">{CURRENCY}</span>
            </p>
            {product.discountPrice && (
              <p className="text-neutral-500 line-through text-sm ml-2">
                {formatPrice(product.price)}
              </p>
            )}
          </div>
          
          <Button
            onClick={(e) => {
              e.stopPropagation();
              e.preventDefault();
              addToCart(product.id, 1);
            }}
            className="bg-primary hover:bg-primary/90 text-white p-2 rounded-full"
            disabled={!product.inStock}
            title={product.inStock ? t("products.addToCart") : t("products.outOfStock")}
          >
            <i className="fas fa-shopping-cart"></i>
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
