import { useEffect } from "react";
import Header from "./Header";
import Footer from "./Footer";
import BackToTop from "./BackToTop";

type LayoutProps = {
  children: React.ReactNode;
};

const Layout = ({ children }: LayoutProps) => {
  // Add event listener for back to top button
  useEffect(() => {
    const handleScroll = () => {
      const backToTopBtn = document.getElementById("backToTopBtn");
      if (backToTopBtn) {
        if (window.pageYOffset > 300) {
          backToTopBtn.classList.remove("hidden");
        } else {
          backToTopBtn.classList.add("hidden");
        }
      }
    };
    
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div className="flex flex-col min-h-screen bg-neutral-100">
      <Header />
      {children}
      <Footer />
      <BackToTop />
    </div>
  );
};

export default Layout;
