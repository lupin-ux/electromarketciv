import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useTranslation } from "react-i18next";
import { useCart } from "@/context/CartContext";
import { NAVIGATION_LINKS, CATEGORIES } from "@/lib/constants";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import CartDrawer from "@/components/cart/CartDrawer";

const Header = () => {
  const { t } = useTranslation();
  const [location] = useLocation();
  const { itemCount } = useCart();
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  // Listen for scroll events to add shadow to header when scrolled
  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      window.location.href = `/products/search?q=${encodeURIComponent(searchQuery)}`;
    }
  };

  return (
    <header className={`bg-white ${isScrolled ? "shadow-md" : ""} sticky top-0 z-40`}>
      {/* Top Bar */}
      <div className="bg-secondary text-white py-2">
        <div className="container mx-auto px-4 flex justify-between items-center">
          <p className="text-sm hidden sm:block">
            <i className="fas fa-phone-alt mr-2"></i> {t("header.phone")}
          </p>
          <div className="flex items-center space-x-4">
            <a href="#" className="text-sm hover:text-accent">{t("header.shipping")}</a>
            <a href="#" className="text-sm hover:text-accent">{t("header.support")}</a>
            <a href="#" className="text-sm hover:text-accent">
              <i className="fas fa-user mr-1"></i> {t("header.myAccount")}
            </a>
          </div>
        </div>
      </div>
      
      {/* Main Header */}
      <div className="container mx-auto px-4 py-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          {/* Logo */}
          <Link href="/" className="text-2xl font-poppins font-bold text-secondary flex items-center mb-4 md:mb-0">
            <i className="fas fa-laptop text-primary mr-2"></i>
            <span>Tech<span className="text-primary">Market</span></span>
          </Link>
          
          {/* Search Bar */}
          <div className="w-full md:w-1/2 mx-4 mb-4 md:mb-0">
            <form onSubmit={handleSearch} className="relative">
              <Input 
                type="text" 
                placeholder={t("header.search")}
                className="w-full py-2 px-4 border border-neutral-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
              <Button 
                type="submit"
                className="absolute right-0 top-0 h-full px-4 bg-primary text-white rounded-r-lg"
              >
                <i className="fas fa-search"></i>
              </Button>
            </form>
          </div>
          
          {/* Cart & Wishlist */}
          <div className="flex items-center space-x-4">
            <Link href="/wishlist" className="flex items-center text-neutral-700 hover:text-primary">
              <i className="fas fa-heart text-xl"></i>
              <span className="ml-1 hidden md:inline">{t("header.wishlist")}</span>
            </Link>
            <button 
              onClick={() => setIsCartOpen(true)}
              className="flex items-center text-neutral-700 hover:text-primary relative"
            >
              <i className="fas fa-shopping-cart text-xl"></i>
              <span className="ml-1 hidden md:inline">{t("header.cart")}</span>
              {itemCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-primary text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  {itemCount}
                </span>
              )}
            </button>
          </div>
        </div>
      </div>
      
      {/* Navigation */}
      <nav className="bg-neutral-100 py-3 border-y border-neutral-200">
        <div className="container mx-auto px-4 relative">
          {/* Mobile Menu Button */}
          <div className="md:hidden flex justify-between items-center">
            <button 
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="text-neutral-700 focus:outline-none"
            >
              <i className={`fas ${isMobileMenuOpen ? 'fa-times' : 'fa-bars'} text-xl`}></i>
              <span className="ml-2">Menu</span>
            </button>
          </div>
          
          {/* Desktop & Mobile Navigation */}
          <ul className={`${isMobileMenuOpen ? 'flex' : 'hidden md:flex'} flex-col md:flex-row md:justify-start md:space-x-6 space-y-2 md:space-y-0 ${isMobileMenuOpen ? 'absolute top-full left-0 right-0 bg-white shadow-lg p-4 z-50' : ''}`}>
            {NAVIGATION_LINKS.map((link, index) => (
              <li key={index} className={link.isDropdown ? "relative group" : ""}>
                {link.isDropdown ? (
                  <>
                    <button className={`px-3 py-2 font-medium ${location === link.path ? 'text-primary' : 'text-neutral-700 hover:text-primary'} flex items-center`}>
                      {t(`navigation.${link.label.toLowerCase()}`)}
                      <i className="fas fa-chevron-down ml-1 text-xs"></i>
                    </button>
                    <div className="absolute left-0 top-full bg-white shadow-lg rounded-lg w-48 p-2 hidden group-hover:block z-10">
                      {CATEGORIES.map((category, idx) => (
                        <Link 
                          key={idx} 
                          href={`/categories/${category.slug}`}
                          className="block px-4 py-2 text-sm hover:bg-accent rounded"
                        >
                          {category.name}
                        </Link>
                      ))}
                    </div>
                  </>
                ) : (
                  <Link 
                    href={link.path}
                    className={`px-3 py-2 font-medium ${location === link.path ? 'text-primary' : 'text-neutral-700 hover:text-primary'}`}
                  >
                    {t(`navigation.${link.label.toLowerCase()}`)}
                  </Link>
                )}
              </li>
            ))}
          </ul>
        </div>
      </nav>

      {/* Cart Drawer */}
      <CartDrawer isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} />
    </header>
  );
};

export default Header;
