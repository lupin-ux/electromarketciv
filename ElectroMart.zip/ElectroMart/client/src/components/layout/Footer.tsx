import { Link } from "wouter";
import { useTranslation } from "react-i18next";
import { 
  COMPANY_INFO, 
  SOCIAL_LINKS, 
  FOOTER_LINKS 
} from "@/lib/constants";

const Footer = () => {
  const { t } = useTranslation();
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-neutral-900 text-white pt-12 pb-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          {/* Company Info */}
          <div>
            <h3 className="text-xl font-poppins font-semibold mb-4 flex items-center">
              <i className="fas fa-laptop text-primary mr-2"></i>
              Tech<span className="text-primary">Market</span>
            </h3>
            <p className="text-neutral-400 mb-4">
              {t("footer.description")}
            </p>
            <div className="flex space-x-4">
              {SOCIAL_LINKS.map((social, index) => (
                <a 
                  key={index} 
                  href={social.url} 
                  aria-label={social.name}
                  className="text-neutral-400 hover:text-primary transition-colors"
                >
                  <i className={social.icon}></i>
                </a>
              ))}
            </div>
          </div>
          
          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-4">{t("footer.quickLinks")}</h4>
            <ul className="space-y-2">
              {FOOTER_LINKS.quick.map((link, index) => (
                <li key={index}>
                  <Link 
                    href={link.path}
                    className="text-neutral-400 hover:text-primary transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          
          {/* Categories */}
          <div>
            <h4 className="text-lg font-semibold mb-4">{t("footer.categories")}</h4>
            <ul className="space-y-2">
              {FOOTER_LINKS.categories.map((link, index) => (
                <li key={index}>
                  <Link 
                    href={link.path}
                    className="text-neutral-400 hover:text-primary transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          
          {/* Contact */}
          <div>
            <h4 className="text-lg font-semibold mb-4">{t("footer.contact")}</h4>
            <ul className="space-y-3">
              <li className="flex items-start">
                <i className="fas fa-map-marker-alt text-primary mt-1 mr-3"></i>
                <span className="text-neutral-400">{COMPANY_INFO.address}</span>
              </li>
              <li className="flex items-center">
                <i className="fas fa-phone-alt text-primary mr-3"></i>
                <span className="text-neutral-400">{COMPANY_INFO.phone}</span>
              </li>
              <li className="flex items-center">
                <i className="fas fa-envelope text-primary mr-3"></i>
                <span className="text-neutral-400">{COMPANY_INFO.email}</span>
              </li>
              <li className="flex items-center">
                <i className="fas fa-clock text-primary mr-3"></i>
                <span className="text-neutral-400">{COMPANY_INFO.hours}</span>
              </li>
            </ul>
          </div>
        </div>
        
        <hr className="border-neutral-800 my-6" />
        
        <div className="flex flex-col md:flex-row justify-between items-center">
          <p className="text-neutral-500 text-sm mb-4 md:mb-0">
            &copy; {currentYear} TechMarket. Tous droits réservés.
          </p>
          <div className="flex items-center space-x-4">
            <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/b7/MasterCard_Logo.svg/200px-MasterCard_Logo.svg.png" alt="MasterCard" className="h-6" loading="lazy" />
            <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/5e/Visa_Inc._logo.svg/200px-Visa_Inc._logo.svg.png" alt="Visa" className="h-6" loading="lazy" />
            <img src="https://upload.wikimedia.org/wikipedia/fr/archive/0/04/20091026205430%21Orange_Money_logo_2013.png" alt="Orange Money" className="h-6" loading="lazy" />
            <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e0/MTN_Mobile_Money_logo.svg/200px-MTN_Mobile_Money_logo.svg.png" alt="MTN Mobile Money" className="h-6" loading="lazy" />
          </div>
        </div>
      </div>

      {/* Back to Top Button */}
      <button 
        onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
        className="fixed bottom-6 right-6 bg-primary text-white rounded-full p-3 shadow-lg hidden"
        id="backToTopBtn"
      >
        <i className="fas fa-chevron-up"></i>
      </button>
    </footer>
  );
};

export default Footer;
