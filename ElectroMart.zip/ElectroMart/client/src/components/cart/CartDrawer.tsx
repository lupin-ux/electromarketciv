import { useTranslation } from "react-i18next";
import { Link } from "wouter";
import { useCart } from "@/hooks/useCart";
import { Button } from "@/components/ui/button";
import { CURRENCY } from "@/lib/constants";
import { formatPrice } from "@/lib/utils";

type CartDrawerProps = {
  isOpen: boolean;
  onClose: () => void;
};

const CartDrawer = ({ isOpen, onClose }: CartDrawerProps) => {
  const { t } = useTranslation();
  const { 
    cartItems, 
    isLoading, 
    removeFromCart, 
    updateQuantity, 
    subtotal 
  } = useCart();

  return (
    <>
      {/* Cart Drawer */}
      <div 
        className={`fixed inset-y-0 right-0 w-full md:w-96 bg-white shadow-xl transform transition-transform duration-300 z-50 ${
          isOpen ? "translate-x-0" : "translate-x-full"
        }`}
      >
        <div className="flex flex-col h-full">
          <div className="flex justify-between items-center px-4 py-4 border-b">
            <h3 className="font-semibold text-lg">
              {t("cart.title", { count: cartItems.length })}
            </h3>
            <button 
              onClick={onClose}
              className="text-neutral-500 hover:text-neutral-700"
              aria-label="Close cart"
            >
              <i className="fas fa-times"></i>
            </button>
          </div>
          
          <div className="flex-grow overflow-auto p-4">
            {isLoading ? (
              <div className="flex justify-center items-center h-full">
                <div className="loader h-8 w-8 rounded-full border-4 border-neutral-200 border-t-primary animate-spin"></div>
              </div>
            ) : cartItems.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-center">
                <i className="fas fa-shopping-cart text-neutral-300 text-5xl mb-4"></i>
                <p className="text-neutral-500">{t("cart.empty")}</p>
              </div>
            ) : (
              cartItems.map((item) => (
                <div key={item.id} className="flex items-center py-4 border-b">
                  <img 
                    src={item.product.imageUrl}
                    alt={item.product.name}
                    className="w-20 h-20 object-cover rounded mr-4"
                    loading="lazy"
                  />
                  <div className="flex-grow">
                    <h4 className="font-medium">{item.product.name}</h4>
                    <p className="text-neutral-500 text-sm">
                      {item.quantity} x {formatPrice(item.product.discountPrice || item.product.price)} {CURRENCY}
                    </p>
                    <div className="flex items-center mt-2">
                      <button 
                        onClick={() => updateQuantity(item.id, Math.max(1, item.quantity - 1))}
                        className="text-xs bg-neutral-100 hover:bg-neutral-200 w-5 h-5 flex items-center justify-center rounded"
                      >
                        -
                      </button>
                      <span className="mx-2 text-xs">{item.quantity}</span>
                      <button 
                        onClick={() => updateQuantity(item.id, item.quantity + 1)}
                        className="text-xs bg-neutral-100 hover:bg-neutral-200 w-5 h-5 flex items-center justify-center rounded"
                      >
                        +
                      </button>
                    </div>
                  </div>
                  <button 
                    onClick={() => removeFromCart(item.id)}
                    className="text-neutral-400 hover:text-error"
                    aria-label="Remove item"
                  >
                    <i className="fas fa-trash-alt"></i>
                  </button>
                </div>
              ))
            )}
          </div>
          
          {!isLoading && cartItems.length > 0 && (
            <div className="p-4 border-t">
              <div className="flex justify-between mb-2">
                <span className="font-medium">{t("cart.subtotal")}</span>
                <span className="font-medium">{formatPrice(subtotal)} {CURRENCY}</span>
              </div>
              <div className="flex justify-between mb-4">
                <span className="text-sm text-neutral-500">{t("cart.shipping")}</span>
                <span className="text-sm text-neutral-500">{t("cart.shippingAtCheckout")}</span>
              </div>
              <Button 
                onClick={() => {
                  window.location.href = "/checkout";
                  onClose();
                }}
                className="w-full bg-primary hover:bg-primary/90 text-white font-medium py-3 rounded-lg mb-2"
              >
                {t("cart.checkout")}
              </Button>
              <Button 
                onClick={onClose}
                variant="outline"
                className="w-full border border-neutral-300 text-primary font-medium py-3 rounded-lg"
              >
                {t("cart.continueShopping")}
              </Button>
            </div>
          )}
        </div>
      </div>

      {/* Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40"
          onClick={onClose}
        ></div>
      )}
    </>
  );
};

export default CartDrawer;
