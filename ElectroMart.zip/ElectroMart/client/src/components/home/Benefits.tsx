import { useTranslation } from "react-i18next";

const Benefits = () => {
  const { t } = useTranslation();

  const benefits = [
    {
      icon: "fa-truck",
      title: t("home.benefits.shipping.title"),
      description: t("home.benefits.shipping.description"),
    },
    {
      icon: "fa-shield-alt",
      title: t("home.benefits.quality.title"),
      description: t("home.benefits.quality.description"),
    },
    {
      icon: "fa-money-bill-wave",
      title: t("home.benefits.payment.title"),
      description: t("home.benefits.payment.description"),
    },
    {
      icon: "fa-headset",
      title: t("home.benefits.support.title"),
      description: t("home.benefits.support.description"),
    },
  ];

  return (
    <section className="py-12 bg-white">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {benefits.map((benefit, index) => (
            <div key={index} className="flex items-start">
              <div className="bg-accent p-3 rounded-full mr-4">
                <i className={`fas ${benefit.icon} text-primary text-xl`}></i>
              </div>
              <div>
                <h3 className="font-semibold text-lg mb-2">{benefit.title}</h3>
                <p className="text-neutral-600 text-sm">{benefit.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Benefits;
