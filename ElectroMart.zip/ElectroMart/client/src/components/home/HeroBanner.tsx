import { useTranslation } from "react-i18next";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

const HeroBanner = () => {
  const { t } = useTranslation();

  return (
    <section className="bg-gradient-to-r from-secondary to-primary text-white py-8 md:py-16">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 mb-8 md:mb-0">
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-poppins font-bold mb-4">
              {t("home.hero.title")}
            </h1>
            <p className="text-lg mb-6 max-w-lg">
              {t("home.hero.description")}
            </p>
            <div className="flex flex-wrap gap-4">
              <Link href="/products">
                <Button className="bg-white text-primary font-semibold px-6 py-3 rounded-lg hover:bg-accent transition duration-300">
                  {t("home.hero.viewProducts")}
                </Button>
              </Link>
              <Link href="/best-deals">
                <Button variant="outline" className="bg-transparent border-2 border-white text-white font-semibold px-6 py-3 rounded-lg hover:bg-white hover:text-primary transition duration-300">
                  {t("home.hero.promotions")}
                </Button>
              </Link>
            </div>
          </div>
          <div className="md:w-1/2">
            <img 
              src="https://images.unsplash.com/photo-1611078489935-0cb964de46d6?ixlib=rb-1.2.1&auto=format&fit=crop&w=700&q=80" 
              alt="Sélection d'appareils électroniques" 
              className="rounded-lg shadow-lg object-cover h-64 w-full md:h-96"
              loading="lazy"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroBanner;
