import { useTranslation } from "react-i18next";
import { Link } from "wouter";
import { CATEGORIES, CATEGORY_ICONS } from "@/lib/constants";

const CategoryBanner = () => {
  const { t } = useTranslation();

  return (
    <section className="py-8 bg-white">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {CATEGORIES.map((category, index) => (
            <Link 
              key={index} 
              href={`/categories/${category.slug}`}
              className="bg-accent rounded-lg p-4 text-center transition hover:shadow-md"
            >
              <i className={`fas ${CATEGORY_ICONS[category.slug as keyof typeof CATEGORY_ICONS]} text-primary text-3xl mb-2`}></i>
              <h3 className="font-medium text-secondary">
                {t(`home.categories.${category.name.toLowerCase().split(' ')[0]}`)}
              </h3>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CategoryBanner;
