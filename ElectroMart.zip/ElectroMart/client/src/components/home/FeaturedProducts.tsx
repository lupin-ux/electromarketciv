import { useTranslation } from "react-i18next";
import { useQuery } from "@tanstack/react-query";
import { Product } from "@shared/schema";
import ProductGrid from "@/components/products/ProductGrid";

const FeaturedProducts = () => {
  const { t } = useTranslation();
  
  const { data: products = [], isLoading, error } = useQuery<Product[]>({
    queryKey: ['/api/products?featured=true'],
  });

  return (
    <section id="products" className="py-12">
      <div className="container mx-auto px-4">
        <ProductGrid 
          products={products}
          isLoading={isLoading}
          error={error}
          title={t("home.featuredProducts.title")}
          showFilters={true}
        />
        
        {/* Pagination */}
        {!isLoading && !error && products.length > 0 && (
          <div className="mt-10 flex justify-center">
            <div className="flex">
              <a href="#" className="h-10 w-10 flex items-center justify-center rounded-l border border-neutral-300 text-primary hover:bg-accent">
                <i className="fas fa-chevron-left"></i>
              </a>
              <a href="#" className="h-10 w-10 flex items-center justify-center border-t border-b border-neutral-300 bg-primary text-white">1</a>
              <a href="#" className="h-10 w-10 flex items-center justify-center border-t border-b border-neutral-300 text-neutral-700 hover:bg-accent">2</a>
              <a href="#" className="h-10 w-10 flex items-center justify-center border-t border-b border-neutral-300 text-neutral-700 hover:bg-accent">3</a>
              <a href="#" className="h-10 w-10 flex items-center justify-center rounded-r border border-neutral-300 text-primary hover:bg-accent">
                <i className="fas fa-chevron-right"></i>
              </a>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};

export default FeaturedProducts;
