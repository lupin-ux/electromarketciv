import { useTranslation } from "react-i18next";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Category } from "@shared/schema";

const FeaturedCategories = () => {
  const { t } = useTranslation();
  
  const { data: categories = [], isLoading } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });

  if (isLoading || categories.length === 0) {
    return null;
  }

  // Only display the first 3 categories
  const displayedCategories = categories.slice(0, 3);

  return (
    <section className="py-12 bg-accent">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl md:text-3xl font-poppins font-semibold text-secondary mb-8 text-center">
          {t("home.featuredCategories.title")}
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {displayedCategories.map((category) => (
            <div key={category.id} className="relative overflow-hidden rounded-lg shadow-md group h-64">
              <img 
                src={category.imageUrl}
                alt={category.name}
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-secondary/70 to-transparent"></div>
              <div className="absolute bottom-0 left-0 right-0 p-6">
                <h3 className="text-white text-xl font-semibold mb-1">{category.name}</h3>
                <p className="text-white/80 mb-3 text-sm">
                  {t("home.featuredCategories.products", { count: 50 })}
                </p>
                <Link href={`/categories/${category.slug}`}>
                  <a className="bg-white text-primary font-medium py-2 px-4 rounded-lg inline-block text-sm hover:bg-accent transition">
                    {t("home.featuredCategories.viewAll")} <i className="fas fa-chevron-right ml-1"></i>
                  </a>
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturedCategories;
