import { Link } from "wouter";

interface CategoryCardProps {
  category: {
    id: number;
    name: string;
    slug: string;
    icon: string;
  };
}

export function CategoryCard({ category }: CategoryCardProps) {
  return (
    <Link href={`/products?category=${category.slug}`} className="group">
      <div className="bg-gray-100 rounded-lg p-6 text-center transition-all duration-200 group-hover:bg-primary-50 group-hover:shadow-md">
        <i className={`fas ${category.icon} text-3xl text-primary-600 mb-3`}></i>
        <h3 className="font-medium">{category.name}</h3>
      </div>
    </Link>
  );
}
