import { useTranslation } from "react-i18next";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { useState } from "react";
import { ProductCard } from "@/components/product-card";
import { CategoryCard } from "@/components/category-card";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { ArrowRight, ShippingFast, Shield, Headphones, Wallet } from "lucide-react";

// Form validation schema
const newsletterSchema = z.object({
  email: z.string().email({ message: "Veuillez entrer une adresse e-mail valide" }),
});

export default function Home() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Form setup
  const form = useForm<z.infer<typeof newsletterSchema>>({
    resolver: zodResolver(newsletterSchema),
    defaultValues: {
      email: "",
    },
  });
  
  // Fetch categories
  const { 
    data: categories, 
    isLoading: isCategoriesLoading 
  } = useQuery({
    queryKey: ["/api/categories"],
  });
  
  // Fetch featured products
  const { 
    data: featuredProducts, 
    isLoading: isFeaturedLoading 
  } = useQuery({
    queryKey: ["/api/products", { featured: true }],
    queryFn: () => fetch("/api/products?featured=true").then(res => res.json()),
  });
  
  // Fetch new arrivals
  const { 
    data: newArrivals, 
    isLoading: isNewArrivalsLoading 
  } = useQuery({
    queryKey: ["/api/products", { newArrivals: true }],
    queryFn: () => fetch("/api/products?newArrivals=true").then(res => res.json()),
  });
  
  // Fetch testimonials
  const { 
    data: testimonials, 
    isLoading: isTestimonialsLoading 
  } = useQuery({
    queryKey: ["/api/testimonials"],
  });
  
  // Handle newsletter form submission
  const onSubmitNewsletter = async (values: z.infer<typeof newsletterSchema>) => {
    try {
      setIsSubmitting(true);
      await apiRequest("POST", "/api/newsletter", values);
      
      form.reset();
      toast({
        title: "Abonnement réussi",
        description: "Vous êtes maintenant abonné à notre newsletter",
      });
    } catch (error) {
      toast({
        title: "Erreur",
        description: "Une erreur s'est produite. Veuillez réessayer.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Loading placeholder for categories
  const CategorySkeleton = () => (
    <>
      {[1, 2, 3, 4, 5, 6].map((i) => (
        <div key={i} className="bg-gray-100 rounded-lg p-6 text-center">
          <Skeleton className="h-12 w-12 rounded-full mx-auto mb-3" />
          <Skeleton className="h-6 w-24 mx-auto" />
        </div>
      ))}
    </>
  );
  
  // Loading placeholder for products
  const ProductSkeleton = () => (
    <>
      {[1, 2, 3, 4].map((i) => (
        <div key={i} className="bg-white rounded-lg shadow-sm overflow-hidden">
          <Skeleton className="w-full h-48" />
          <div className="p-4">
            <Skeleton className="h-6 w-3/4 mb-2" />
            <Skeleton className="h-4 w-1/2 mb-4" />
            <div className="flex justify-between items-center">
              <Skeleton className="h-6 w-20" />
              <Skeleton className="h-8 w-24 rounded" />
            </div>
          </div>
        </div>
      ))}
    </>
  );
  
  // Loading placeholder for testimonials
  const TestimonialSkeleton = () => (
    <>
      {[1, 2, 3].map((i) => (
        <div key={i} className="bg-white p-6 rounded-lg shadow-sm">
          <Skeleton className="h-4 w-24 mb-4" />
          <Skeleton className="h-16 w-full mb-6" />
          <div className="flex items-center">
            <Skeleton className="w-10 h-10 rounded-full mr-3" />
            <div>
              <Skeleton className="h-4 w-20 mb-1" />
              <Skeleton className="h-3 w-16" />
            </div>
          </div>
        </div>
      ))}
    </>
  );

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-primary-700 to-primary-900 text-white">
        <div className="container mx-auto px-4 py-12 md:py-24">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div className="space-y-6">
              <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold">
                {t('home.hero.title')}
              </h1>
              <p className="text-lg opacity-90">
                {t('home.hero.subtitle')}
              </p>
              <div className="flex flex-wrap gap-4">
                <Button asChild className="bg-amber-500 hover:bg-amber-600 text-white">
                  <Link href="#products">
                    <span>{t('home.hero.cta1')}</span>
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
                <Button asChild variant="outline" className="bg-white hover:bg-gray-100 text-primary-800">
                  <Link href="/contact">
                    {t('home.hero.cta2')}
                  </Link>
                </Button>
              </div>
            </div>
            <div className="hidden md:block relative">
              <img
                src="https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?auto=format&fit=crop&w=600&h=400"
                alt="Appareils électroniques modernes"
                className="rounded-lg shadow-xl mx-auto object-cover"
                width="600"
                height="400"
              />
              <div className="absolute -bottom-6 -left-6 bg-amber-500 text-white px-6 py-3 rounded-lg font-bold">
                {t('home.hero.delivery')}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-bold text-center mb-8">
            {t('home.categories.title')}
          </h2>
          
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {isCategoriesLoading ? (
              <CategorySkeleton />
            ) : (
              categories?.map((category) => (
                <CategoryCard key={category.id} category={category} />
              ))
            )}
          </div>
        </div>
      </section>

      {/* Featured Products Section */}
      <section id="products" className="py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-2xl md:text-3xl font-bold">
              {t('home.featuredProducts.title')}
            </h2>
            <Link href="/products" className="text-primary-600 hover:text-primary-700 font-medium flex items-center">
              <span>{t('home.featuredProducts.viewAll')}</span>
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {isFeaturedLoading ? (
              <ProductSkeleton />
            ) : (
              featuredProducts?.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))
            )}
          </div>
          
          <div className="mt-10 text-center">
            <Button asChild variant="outline" className="border-primary-600 text-primary-600 hover:bg-primary-600 hover:text-white">
              <Link href="/products">
                <span>{t('common.viewAll')}</span>
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-bold text-center mb-12">
            {t('home.benefits.title')}
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="mx-auto w-16 h-16 flex items-center justify-center bg-primary-100 text-primary-600 rounded-full mb-4">
                <ShippingFast className="h-8 w-8" />
              </div>
              <h3 className="text-lg font-semibold mb-2">
                {t('home.benefits.delivery.title')}
              </h3>
              <p className="text-gray-600">
                {t('home.benefits.delivery.description')}
              </p>
            </div>
            
            <div className="text-center">
              <div className="mx-auto w-16 h-16 flex items-center justify-center bg-primary-100 text-primary-600 rounded-full mb-4">
                <Shield className="h-8 w-8" />
              </div>
              <h3 className="text-lg font-semibold mb-2">
                {t('home.benefits.quality.title')}
              </h3>
              <p className="text-gray-600">
                {t('home.benefits.quality.description')}
              </p>
            </div>
            
            <div className="text-center">
              <div className="mx-auto w-16 h-16 flex items-center justify-center bg-primary-100 text-primary-600 rounded-full mb-4">
                <Headphones className="h-8 w-8" />
              </div>
              <h3 className="text-lg font-semibold mb-2">
                {t('home.benefits.support.title')}
              </h3>
              <p className="text-gray-600">
                {t('home.benefits.support.description')}
              </p>
            </div>
            
            <div className="text-center">
              <div className="mx-auto w-16 h-16 flex items-center justify-center bg-primary-100 text-primary-600 rounded-full mb-4">
                <Wallet className="h-8 w-8" />
              </div>
              <h3 className="text-lg font-semibold mb-2">
                {t('home.benefits.payment.title')}
              </h3>
              <p className="text-gray-600">
                {t('home.benefits.payment.description')}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="py-12 bg-primary-700 text-white">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="text-center mb-8">
            <h2 className="text-2xl md:text-3xl font-bold mb-2">
              {t('home.newsletter.title')}
            </h2>
            <p className="opacity-90">
              {t('home.newsletter.subtitle')}
            </p>
          </div>
          
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmitNewsletter)} className="flex flex-col sm:flex-row gap-3 max-w-lg mx-auto">
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem className="flex-1">
                    <FormControl>
                      <Input
                        placeholder={t('home.newsletter.placeholder')}
                        className="py-3 px-4 rounded-lg text-gray-800 focus:outline-none focus:ring-2 focus:ring-amber-500"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button 
                type="submit" 
                className="bg-amber-500 hover:bg-amber-600 text-white font-medium py-3 px-6 rounded-lg"
                disabled={isSubmitting}
              >
                {t('home.newsletter.button')}
              </Button>
            </form>
          </Form>
        </div>
      </section>

      {/* New Arrivals Section */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-2xl md:text-3xl font-bold">
              {t('home.newArrivals.title')}
            </h2>
            <Link href="/products?newArrivals=true" className="text-primary-600 hover:text-primary-700 font-medium flex items-center">
              <span>{t('home.newArrivals.viewAll')}</span>
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {isNewArrivalsLoading ? (
              <ProductSkeleton />
            ) : (
              newArrivals?.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))
            )}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-12 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-bold text-center mb-12">
            {t('home.testimonials.title')}
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {isTestimonialsLoading ? (
              <TestimonialSkeleton />
            ) : (
              testimonials?.map((testimonial) => (
                <div key={testimonial.id} className="bg-white p-6 rounded-lg shadow-sm">
                  <div className="text-amber-500 flex mb-4">
                    {Array(5).fill(0).map((_, i) => (
                      <i key={i} className={`fas ${i < testimonial.rating ? 'fa-star' : 'fa-star-o'}`}></i>
                    ))}
                  </div>
                  <p className="text-gray-600 mb-6">{testimonial.comment}</p>
                  <div className="flex items-center">
                    <div className="w-10 h-10 bg-gray-300 rounded-full overflow-hidden mr-3">
                      <img 
                        src={testimonial.imageUrl || 'https://randomuser.me/api/portraits/men/32.jpg'} 
                        alt={testimonial.name}
                        width="40"
                        height="40"
                      />
                    </div>
                    <div>
                      <h4 className="font-medium">{testimonial.name}</h4>
                      <p className="text-gray-500 text-sm">{testimonial.location}</p>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </section>

      {/* Contact CTA Section */}
      <section id="contact" className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <div className="bg-gradient-to-r from-primary-700 to-primary-900 rounded-xl overflow-hidden shadow-xl">
            <div className="md:flex">
              <div className="md:w-1/2 p-8 md:p-12">
                <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">
                  {t('contact.title')}
                </h2>
                <p className="text-primary-100 mb-8">
                  {t('contact.subtitle')}
                </p>
                
                <div className="space-y-6">
                  <div className="flex items-start">
                    <div className="text-amber-500 mr-3 mt-1">
                      <i className="fas fa-map-marker-alt"></i>
                    </div>
                    <div className="text-white">
                      <h3 className="font-semibold mb-1">{t('contact.address.title')}</h3>
                      <p className="text-primary-100">{t('contact.address.value')}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="text-amber-500 mr-3 mt-1">
                      <i className="fas fa-phone-alt"></i>
                    </div>
                    <div className="text-white">
                      <h3 className="font-semibold mb-1">{t('contact.phone.title')}</h3>
                      <p className="text-primary-100">{t('contact.phone.value')}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="text-amber-500 mr-3 mt-1">
                      <i className="fas fa-envelope"></i>
                    </div>
                    <div className="text-white">
                      <h3 className="font-semibold mb-1">{t('contact.email.title')}</h3>
                      <p className="text-primary-100">{t('contact.email.value')}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="text-amber-500 mr-3 mt-1">
                      <i className="fas fa-clock"></i>
                    </div>
                    <div className="text-white">
                      <h3 className="font-semibold mb-1">{t('contact.hours.title')}</h3>
                      <p className="text-primary-100">
                        {t('contact.hours.weekdays')}<br />
                        {t('contact.hours.weekend')}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="md:w-1/2 p-8 md:p-12 bg-white">
                <h3 className="text-xl font-bold text-gray-800 mb-6">
                  {t('contact.form.title')}
                </h3>
                
                <Link href="/contact">
                  <Button className="w-full bg-primary-600 hover:bg-primary-700 text-white font-medium py-2 px-4 rounded-md">
                    {t('contact.form.submit')}
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
