import { useTranslation } from "react-i18next";
import { useQuery } from "@tanstack/react-query";
import ProductGrid from "@/components/products/ProductGrid";
import { Product } from "@shared/schema";
import { Helmet } from "react-helmet";

const Products = () => {
  const { t } = useTranslation();
  
  const { data: products = [], isLoading, error } = useQuery<Product[]>({
    queryKey: ['/api/products'],
  });

  return (
    <>
      <Helmet>
        <title>Tous les Produits | TechMarket Côte d'Ivoire</title>
        <meta name="description" content="Explorez notre gamme complète de produits électroniques, laptops, smartphones et accessoires en Côte d'Ivoire." />
      </Helmet>

      <main className="py-8">
        <div className="container mx-auto px-4">
          <div className="mb-6">
            <h1 className="text-3xl font-poppins font-bold text-secondary mb-2">Tous nos produits</h1>
            <div className="flex items-center text-sm text-neutral-500">
              <a href="/" className="hover:text-primary">Accueil</a>
              <span className="mx-2">/</span>
              <span>Produits</span>
            </div>
          </div>

          <ProductGrid 
            products={products}
            isLoading={isLoading}
            error={error}
            showFilters={true}
          />
        </div>
      </main>
    </>
  );
};

export default Products;
