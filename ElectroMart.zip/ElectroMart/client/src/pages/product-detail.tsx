import { useTranslation } from "react-i18next";
import { useQuery } from "@tanstack/react-query";
import { useRoute, Link } from "wouter";
import { useState } from "react";
import { useCart } from "@/components/cart-provider";
import { Button } from "@/components/ui/button";
import { 
  Card, 
  CardContent 
} from "@/components/ui/card";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import { ProductCard } from "@/components/product-card";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  MinusCircle,
  PlusCircle,
  ShoppingCart,
  Heart,
  Share2,
  Star,
  Truck,
  Shield,
  RefreshCw
} from "lucide-react";

export default function ProductDetail() {
  const { t } = useTranslation();
  const [, params] = useRoute("/products/:slug");
  const { addToCart } = useCart();
  const [quantity, setQuantity] = useState(1);
  
  // Get product details
  const { 
    data: product, 
    isLoading: isProductLoading,
    error: productError
  } = useQuery({
    queryKey: ["/api/products", params?.slug],
    queryFn: () => fetch(`/api/products/${params?.slug}`).then(res => res.json()),
    enabled: !!params?.slug
  });
  
  // Get related products (same category)
  const { 
    data: relatedProducts, 
    isLoading: isRelatedLoading 
  } = useQuery({
    queryKey: ["/api/products", { categoryId: product?.categoryId }],
    queryFn: () => fetch(`/api/products?categoryId=${product.categoryId}`).then(res => res.json()),
    enabled: !!product?.categoryId
  });
  
  // Handle quantity change
  const increaseQuantity = () => {
    if (product && quantity < product.stock) {
      setQuantity(quantity + 1);
    }
  };
  
  const decreaseQuantity = () => {
    if (quantity > 1) {
      setQuantity(quantity - 1);
    }
  };
  
  // Add to cart handler
  const handleAddToCart = () => {
    if (product) {
      addToCart(product.id, quantity);
    }
  };
  
  // Format price
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('fr-CI').format(price);
  };
  
  // Generate stars for rating
  const renderRatingStars = (rating: number = 0) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const halfStar = rating % 1 >= 0.5;
    
    for (let i = 0; i < fullStars; i++) {
      stars.push(<Star key={`star-${i}`} className="fill-amber-500 text-amber-500 h-5 w-5" />);
    }
    
    if (halfStar) {
      stars.push(
        <div key="half-star" className="relative">
          <Star className="text-gray-300 h-5 w-5" />
          <Star className="absolute top-0 left-0 fill-amber-500 text-amber-500 h-5 w-5 overflow-hidden" style={{ clipPath: 'inset(0 50% 0 0)' }} />
        </div>
      );
    }
    
    const emptyStars = 5 - fullStars - (halfStar ? 1 : 0);
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<Star key={`empty-${i}`} className="text-gray-300 h-5 w-5" />);
    }
    
    return <div className="flex">{stars}</div>;
  };
  
  // Loading UI
  if (isProductLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="grid md:grid-cols-2 gap-8">
          <Skeleton className="aspect-square rounded-lg" />
          <div className="space-y-4">
            <Skeleton className="h-10 w-3/4" />
            <Skeleton className="h-6 w-1/2" />
            <Skeleton className="h-6 w-1/4" />
            <div className="py-4">
              <Skeleton className="h-24 w-full" />
            </div>
            <div className="flex space-x-4">
              <Skeleton className="h-12 w-1/3" />
              <Skeleton className="h-12 w-1/3" />
            </div>
          </div>
        </div>
      </div>
    );
  }
  
  // Error UI
  if (productError || !product) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Card>
          <CardContent className="flex flex-col items-center justify-center p-8">
            <h1 className="text-2xl font-bold mb-4">Produit non trouvé</h1>
            <p className="text-gray-500 mb-6">Le produit que vous cherchez n'existe pas ou a été retiré.</p>
            <Button asChild>
              <Link href="/products">Voir tous les produits</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Product details section */}
      <div className="grid md:grid-cols-2 gap-8 mb-12">
        {/* Product image */}
        <div className="bg-white rounded-lg overflow-hidden">
          <img 
            src={product.imageUrl} 
            alt={product.name} 
            className="w-full h-auto object-cover"
          />
        </div>
        
        {/* Product info */}
        <div className="space-y-4">
          <h1 className="text-3xl font-bold">{product.name}</h1>
          
          {/* Rating */}
          {product.rating && (
            <div className="flex items-center space-x-2">
              {renderRatingStars(product.rating)}
              <span className="text-gray-500">
                ({product.reviewCount || 0} {t('products.reviews')})
              </span>
            </div>
          )}
          
          {/* Price */}
          <div className="text-2xl font-bold">
            {product.discountPrice ? (
              <>
                {formatPrice(product.discountPrice)} {t('common.currency')}
                <span className="text-gray-500 line-through text-xl ml-2">
                  {formatPrice(product.price)} {t('common.currency')}
                </span>
              </>
            ) : (
              <>
                {formatPrice(product.price)} {t('common.currency')}
              </>
            )}
          </div>
          
          {/* Description */}
          <p className="text-gray-600">{product.description}</p>
          
          {/* Stock status */}
          <div className="flex items-center py-1">
            <span className={`inline-block w-3 h-3 rounded-full mr-2 ${product.stock > 0 ? 'bg-green-500' : 'bg-red-500'}`}></span>
            <span>
              {product.stock > 0 
                ? `En stock (${product.stock})` 
                : "Rupture de stock"}
            </span>
          </div>
          
          {/* Features */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 py-4">
            <div className="flex items-center">
              <Truck className="mr-2 text-primary-600 h-5 w-5" />
              <span className="text-sm">Livraison 24-48h</span>
            </div>
            <div className="flex items-center">
              <Shield className="mr-2 text-primary-600 h-5 w-5" />
              <span className="text-sm">Garantie 1 an</span>
            </div>
            <div className="flex items-center">
              <RefreshCw className="mr-2 text-primary-600 h-5 w-5" />
              <span className="text-sm">Retour sous 14 jours</span>
            </div>
          </div>
          
          {/* Quantity and add to cart */}
          <div className="flex flex-wrap gap-4 items-center py-4">
            <div className="flex items-center border rounded-md">
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={decreaseQuantity} 
                disabled={quantity <= 1}
              >
                <MinusCircle className="h-4 w-4" />
              </Button>
              <span className="w-12 text-center">{quantity}</span>
              <Button 
                variant="ghost" 
                size="icon" 
                onClick={increaseQuantity}
                disabled={quantity >= product.stock}
              >
                <PlusCircle className="h-4 w-4" />
              </Button>
            </div>
            
            <Button 
              className="bg-primary-600 hover:bg-primary-700" 
              onClick={handleAddToCart}
              disabled={product.stock <= 0}
            >
              <ShoppingCart className="mr-2 h-5 w-5" />
              {t('products.addToCart')}
            </Button>
            
            <Button variant="outline" size="icon">
              <Heart className="h-5 w-5" />
            </Button>
            
            <Button variant="outline" size="icon">
              <Share2 className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </div>
      
      {/* Product details tabs */}
      <Tabs defaultValue="specifications" className="mb-12">
        <TabsList className="grid w-full grid-cols-2 md:w-auto md:inline-flex">
          <TabsTrigger value="specifications">{t('products.specifications')}</TabsTrigger>
          <TabsTrigger value="reviews">{t('products.reviews')}</TabsTrigger>
        </TabsList>
        
        <TabsContent value="specifications" className="bg-white p-6 rounded-lg mt-4">
          {product.specifications ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {Object.entries(product.specifications as Record<string, string>).map(([key, value]) => (
                <div key={key} className="flex justify-between border-b pb-2">
                  <span className="font-medium capitalize">{key}</span>
                  <span className="text-gray-600">{value}</span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-gray-500">Aucune spécification disponible pour ce produit.</p>
          )}
        </TabsContent>
        
        <TabsContent value="reviews" className="bg-white p-6 rounded-lg mt-4">
          {product.reviewCount && product.reviewCount > 0 ? (
            <div className="flex items-center mb-4">
              <div className="flex mr-2">
                {renderRatingStars(product.rating || 0)}
              </div>
              <span className="text-gray-600">
                {product.rating?.toFixed(1)} sur 5 ({product.reviewCount} avis)
              </span>
            </div>
          ) : (
            <p className="text-gray-500">Aucun avis disponible pour ce produit.</p>
          )}
        </TabsContent>
      </Tabs>
      
      {/* Related products */}
      {relatedProducts && relatedProducts.length > 0 && (
        <div className="mb-12">
          <h2 className="text-2xl font-bold mb-6">{t('products.relatedProducts')}</h2>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {isRelatedLoading ? (
              Array(4).fill(0).map((_, i) => (
                <Skeleton key={i} className="h-80 rounded-lg" />
              ))
            ) : (
              relatedProducts
                .filter(p => p.id !== product.id)
                .slice(0, 4)
                .map(product => (
                  <ProductCard key={product.id} product={product} />
                ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}
