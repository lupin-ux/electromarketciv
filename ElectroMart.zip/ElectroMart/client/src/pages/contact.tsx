import { useState } from "react";
import { useTranslation } from "react-i18next";
import { 
  Card,
  CardContent 
} from "@/components/ui/card";
import { 
  Form, 
  FormControl, 
  FormField, 
  FormItem, 
  FormLabel, 
  FormMessage 
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { MapPin, Phone, Mail, Clock } from "lucide-react";

// Form validation schema
const contactFormSchema = z.object({
  name: z.string().min(2, { message: "Le nom doit contenir au moins 2 caractères" }),
  email: z.string().email({ message: "Email invalide" }),
  phone: z.string().optional(),
  message: z.string().min(10, { message: "Le message doit contenir au moins 10 caractères" })
});

export default function Contact() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Form setup
  const form = useForm<z.infer<typeof contactFormSchema>>({
    resolver: zodResolver(contactFormSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      message: ""
    }
  });

  // Handle form submission
  const onSubmit = async (values: z.infer<typeof contactFormSchema>) => {
    try {
      setIsSubmitting(true);
      await apiRequest("POST", "/api/contact", values);
      
      form.reset();
      toast({
        title: t('contact.form.success'),
        description: "Nous vous contacterons bientôt",
      });
    } catch (error) {
      toast({
        title: t('contact.form.error'),
        description: "Veuillez vérifier vos informations et réessayer",
        variant: "destructive",
      });
      console.error("Contact form submission error:", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold text-center mb-8">{t('contact.title')}</h1>
      
      <div className="bg-gradient-to-r from-primary-700 to-primary-900 rounded-xl overflow-hidden shadow-xl mb-12">
        <div className="md:flex">
          {/* Contact Information */}
          <div className="md:w-1/2 p-8 md:p-12">
            <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">
              {t('contact.title')}
            </h2>
            <p className="text-primary-100 mb-8">
              {t('contact.subtitle')}
            </p>
            
            <div className="space-y-6">
              <div className="flex items-start">
                <div className="text-amber-500 mr-3 mt-1">
                  <MapPin className="h-5 w-5" />
                </div>
                <div className="text-white">
                  <h3 className="font-semibold mb-1">{t('contact.address.title')}</h3>
                  <p className="text-primary-100">{t('contact.address.value')}</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="text-amber-500 mr-3 mt-1">
                  <Phone className="h-5 w-5" />
                </div>
                <div className="text-white">
                  <h3 className="font-semibold mb-1">{t('contact.phone.title')}</h3>
                  <p className="text-primary-100">{t('contact.phone.value')}</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="text-amber-500 mr-3 mt-1">
                  <Mail className="h-5 w-5" />
                </div>
                <div className="text-white">
                  <h3 className="font-semibold mb-1">{t('contact.email.title')}</h3>
                  <p className="text-primary-100">{t('contact.email.value')}</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="text-amber-500 mr-3 mt-1">
                  <Clock className="h-5 w-5" />
                </div>
                <div className="text-white">
                  <h3 className="font-semibold mb-1">{t('contact.hours.title')}</h3>
                  <p className="text-primary-100">
                    {t('contact.hours.weekdays')}<br />
                    {t('contact.hours.weekend')}
                  </p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Contact Form */}
          <div className="md:w-1/2 p-8 md:p-12 bg-white">
            <h3 className="text-xl font-bold text-gray-800 mb-6">
              {t('contact.form.title')}
            </h3>
            
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t('contact.form.name')}</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t('contact.form.email')}</FormLabel>
                      <FormControl>
                        <Input type="email" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t('contact.form.phone')}</FormLabel>
                      <FormControl>
                        <Input type="tel" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="message"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t('contact.form.message')}</FormLabel>
                      <FormControl>
                        <Textarea rows={4} {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <Button 
                  type="submit" 
                  className="w-full bg-primary-600 hover:bg-primary-700 text-white font-medium py-2 px-4"
                  disabled={isSubmitting}
                >
                  {isSubmitting ? t('common.loading') : t('contact.form.submit')}
                </Button>
              </form>
            </Form>
          </div>
        </div>
      </div>
      
      {/* Map Section */}
      <div className="rounded-lg overflow-hidden h-96 shadow-md">
        <iframe 
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d127176.27886217673!2d-4.060087287760368!3d5.3383401772424105!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xfc1ea5311959121%3A0x3fe70ddce19221a6!2sAbidjan%2C%20C%C3%B4te%20d&#39;Ivoire!5e0!3m2!1sfr!2sus!4v1678974345399!5m2!1sfr!2sus" 
          width="100%" 
          height="100%" 
          style={{ border: 0 }} 
          allowFullScreen={true} 
          loading="lazy" 
          referrerPolicy="no-referrer-when-downgrade"
          title="TechStore Location"
        ></iframe>
      </div>
    </div>
  );
}
