import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { COMPANY_INFO } from "@/lib/constants";
import { useToast } from "@/hooks/use-toast";
import { Helmet } from "react-helmet";

// Form validation schema
const contactSchema = z.object({
  name: z.string().min(2, "Le nom doit contenir au moins 2 caractères"),
  email: z.string().email("Veuillez entrer une adresse email valide"),
  subject: z.string().min(5, "Le sujet doit contenir au moins 5 caractères"),
  message: z.string().min(10, "Le message doit contenir au moins 10 caractères")
});

type ContactFormData = z.infer<typeof contactSchema>;

const Contact = () => {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const { 
    register, 
    handleSubmit, 
    reset,
    formState: { errors } 
  } = useForm<ContactFormData>({
    resolver: zodResolver(contactSchema)
  });

  const onSubmit = async (data: ContactFormData) => {
    setIsSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      toast({
        title: "Message envoyé",
        description: "Nous vous répondrons dans les plus brefs délais.",
      });
      reset();
      setIsSubmitting(false);
    }, 1500);
  };

  return (
    <>
      <Helmet>
        <title>Contact | TechMarket Côte d'Ivoire</title>
        <meta name="description" content="Contactez TechMarket pour toute question concernant nos produits ou services en Côte d'Ivoire." />
      </Helmet>

      <main>
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-secondary to-primary text-white py-12">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-3xl md:text-4xl font-poppins font-bold mb-4">
              {t("contact.title")}
            </h1>
            <p className="text-xl max-w-2xl mx-auto">
              {t("contact.description")}
            </p>
          </div>
        </section>

        {/* Contact Content */}
        <section className="py-12">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Contact Info */}
              <div className="lg:col-span-1">
                <div className="bg-white rounded-lg shadow-sm p-6">
                  <h2 className="text-xl font-poppins font-semibold text-secondary mb-6">
                    Nos Coordonnées
                  </h2>
                  
                  <div className="space-y-4">
                    <div className="flex items-start">
                      <div className="bg-accent p-3 rounded-full mr-4">
                        <i className="fas fa-map-marker-alt text-primary"></i>
                      </div>
                      <div>
                        <h3 className="font-medium text-neutral-800 mb-1">Adresse</h3>
                        <p className="text-neutral-600 text-sm">{COMPANY_INFO.address}</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start">
                      <div className="bg-accent p-3 rounded-full mr-4">
                        <i className="fas fa-phone-alt text-primary"></i>
                      </div>
                      <div>
                        <h3 className="font-medium text-neutral-800 mb-1">Téléphone</h3>
                        <p className="text-neutral-600 text-sm">{COMPANY_INFO.phone}</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start">
                      <div className="bg-accent p-3 rounded-full mr-4">
                        <i className="fas fa-envelope text-primary"></i>
                      </div>
                      <div>
                        <h3 className="font-medium text-neutral-800 mb-1">Email</h3>
                        <p className="text-neutral-600 text-sm">{COMPANY_INFO.email}</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start">
                      <div className="bg-accent p-3 rounded-full mr-4">
                        <i className="fas fa-clock text-primary"></i>
                      </div>
                      <div>
                        <h3 className="font-medium text-neutral-800 mb-1">Heures d'ouverture</h3>
                        <p className="text-neutral-600 text-sm">{COMPANY_INFO.hours}</p>
                      </div>
                    </div>
                  </div>
                  
                  <hr className="my-6" />
                  
                  <h3 className="font-medium text-neutral-800 mb-3">Suivez-nous</h3>
                  <div className="flex space-x-3">
                    <a href="#" className="bg-blue-600 text-white w-10 h-10 rounded-full flex items-center justify-center hover:bg-blue-700">
                      <i className="fab fa-facebook-f"></i>
                    </a>
                    <a href="#" className="bg-blue-400 text-white w-10 h-10 rounded-full flex items-center justify-center hover:bg-blue-500">
                      <i className="fab fa-twitter"></i>
                    </a>
                    <a href="#" className="bg-pink-600 text-white w-10 h-10 rounded-full flex items-center justify-center hover:bg-pink-700">
                      <i className="fab fa-instagram"></i>
                    </a>
                    <a href="#" className="bg-green-500 text-white w-10 h-10 rounded-full flex items-center justify-center hover:bg-green-600">
                      <i className="fab fa-whatsapp"></i>
                    </a>
                  </div>
                </div>
              </div>
              
              {/* Contact Form */}
              <div className="lg:col-span-2">
                <div className="bg-white rounded-lg shadow-sm p-6">
                  <h2 className="text-xl font-poppins font-semibold text-secondary mb-6">
                    Envoyez-nous un message
                  </h2>
                  
                  <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label htmlFor="name" className="block text-sm font-medium text-neutral-700 mb-1">
                          {t("contact.form.name")} *
                        </label>
                        <Input
                          id="name"
                          {...register("name")}
                          placeholder="Votre nom complet"
                          className={errors.name ? "border-error" : ""}
                        />
                        {errors.name && (
                          <p className="text-error text-xs mt-1">{errors.name.message}</p>
                        )}
                      </div>
                      
                      <div>
                        <label htmlFor="email" className="block text-sm font-medium text-neutral-700 mb-1">
                          {t("contact.form.email")} *
                        </label>
                        <Input
                          id="email"
                          type="email"
                          {...register("email")}
                          placeholder="Votre adresse email"
                          className={errors.email ? "border-error" : ""}
                        />
                        {errors.email && (
                          <p className="text-error text-xs mt-1">{errors.email.message}</p>
                        )}
                      </div>
                    </div>
                    
                    <div>
                      <label htmlFor="subject" className="block text-sm font-medium text-neutral-700 mb-1">
                        {t("contact.form.subject")} *
                      </label>
                      <Input
                        id="subject"
                        {...register("subject")}
                        placeholder="Sujet de votre message"
                        className={errors.subject ? "border-error" : ""}
                      />
                      {errors.subject && (
                        <p className="text-error text-xs mt-1">{errors.subject.message}</p>
                      )}
                    </div>
                    
                    <div>
                      <label htmlFor="message" className="block text-sm font-medium text-neutral-700 mb-1">
                        {t("contact.form.message")} *
                      </label>
                      <Textarea
                        id="message"
                        {...register("message")}
                        placeholder="Votre message"
                        rows={6}
                        className={errors.message ? "border-error" : ""}
                      />
                      {errors.message && (
                        <p className="text-error text-xs mt-1">{errors.message.message}</p>
                      )}
                    </div>
                    
                    <div>
                      <Button 
                        type="submit" 
                        className="bg-primary hover:bg-primary/90 text-white w-full md:w-auto px-8 py-3"
                        disabled={isSubmitting}
                      >
                        {isSubmitting ? (
                          <span className="flex items-center">
                            <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                            </svg>
                            Envoi en cours...
                          </span>
                        ) : (
                          t("contact.form.send")
                        )}
                      </Button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </section>
        
        {/* Map Section */}
        <section className="py-8">
          <div className="container mx-auto px-4">
            <div className="bg-white rounded-lg shadow-sm overflow-hidden">
              <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d31857.08275894489!2d-3.988572!3d5.348799!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xfc1ea5311959121%3A0x3fe70ddce19221a6!2sCocody%2C%20Abidjan%2C%20C%C3%B4te%20d&#39;Ivoire!5e0!3m2!1sfr!2sfr!4v1628000000000!5m2!1sfr!2sfr" 
                width="100%" 
                height="450" 
                style={{ border: 0 }} 
                allowFullScreen={true} 
                loading="lazy"
                title="TechMarket location"
              ></iframe>
            </div>
          </div>
        </section>
      </main>
    </>
  );
};

export default Contact;
