import { useTranslation } from "react-i18next";
import { useParams, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Product, Category } from "@shared/schema";
import ProductDetail from "@/components/products/ProductDetail";
import ProductGrid from "@/components/products/ProductGrid";
import { Helmet } from "react-helmet";

const ProductDetailPage = () => {
  const { t } = useTranslation();
  const { slug } = useParams();
  const [, setLocation] = useLocation();
  
  // Fetch product details
  const { 
    data: productData, 
    isLoading, 
    error 
  } = useQuery<Product & { category?: Category }>({
    queryKey: [`/api/products/${slug}`],
  });
  
  // Fetch related products (from same category)
  const { data: relatedProducts = [] } = useQuery<Product[]>({
    queryKey: [`/api/products?categoryId=${productData?.categoryId}`],
    enabled: !!productData?.categoryId,
  });

  if (error) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <h1 className="text-2xl font-bold text-error mb-4">Erreur lors du chargement du produit</h1>
        <p className="text-neutral-600 mb-6">
          Nous n'avons pas pu charger les détails de ce produit. Veuillez réessayer ultérieurement.
        </p>
        <button 
          onClick={() => setLocation("/products")} 
          className="bg-primary text-white px-4 py-2 rounded-lg hover:bg-primary/90"
        >
          Retour aux produits
        </button>
      </div>
    );
  }

  return (
    <>
      {productData && (
        <Helmet>
          <title>{productData.name} | TechMarket Côte d'Ivoire</title>
          <meta name="description" content={productData.description || `Découvrez le ${productData.name} et ses caractéristiques sur TechMarket Côte d'Ivoire.`} />
        </Helmet>
      )}

      <main className="py-8">
        <div className="container mx-auto px-4">
          {/* Breadcrumb */}
          <div className="mb-6">
            <div className="flex items-center text-sm text-neutral-500">
              <a href="/" className="hover:text-primary">Accueil</a>
              <span className="mx-2">/</span>
              <a href="/products" className="hover:text-primary">Produits</a>
              {productData?.category && (
                <>
                  <span className="mx-2">/</span>
                  <a href={`/categories/${productData.category.slug}`} className="hover:text-primary">
                    {productData.category.name}
                  </a>
                </>
              )}
              <span className="mx-2">/</span>
              <span className="text-primary">{productData?.name}</span>
            </div>
          </div>

          {/* Product Detail */}
          <ProductDetail 
            product={productData as Product & { category?: Category }} 
            isLoading={isLoading} 
          />
          
          {/* Related Products */}
          {relatedProducts.length > 0 && (
            <div className="mt-16">
              <h2 className="text-2xl font-poppins font-semibold text-secondary mb-8">
                {t("products.relatedProducts")}
              </h2>
              <ProductGrid 
                products={relatedProducts.filter(p => p.id !== productData?.id).slice(0, 4)} 
              />
            </div>
          )}
        </div>
      </main>
    </>
  );
};

export default ProductDetailPage;
