import { useTranslation } from "react-i18next";
import { useQuery } from "@tanstack/react-query";
import { useLocation, useSearch } from "wouter";
import { useState, useEffect, useMemo } from "react";
import { ProductCard } from "@/components/product-card";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue
} from "@/components/ui/select";
import { 
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger
} from "@/components/ui/accordion";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Separator } from "@/components/ui/separator";
import { Card } from "@/components/ui/card";
import { Filter, SlidersHorizontal, Search } from "lucide-react";
import { useMobile } from "@/hooks/use-mobile";

// Price range for slider
const PRICE_RANGE = {
  min: 0,
  max: 1000000, // 1,000,000 FCFA
};

// Sort options
const SORT_OPTIONS = [
  { value: "default", label: "Pertinence" },
  { value: "price-asc", label: "Prix: croissant" },
  { value: "price-desc", label: "Prix: décroissant" },
  { value: "newest", label: "Plus récents" },
  { value: "rating", label: "Meilleures notes" },
];

export default function Products() {
  const { t } = useTranslation();
  const [location, setLocation] = useLocation();
  const search = useSearch();
  const isMobile = useMobile();
  
  // Parse search params
  const searchParams = useMemo(() => new URLSearchParams(search), [search]);
  const categorySlug = searchParams.get("category");
  const searchQuery = searchParams.get("search");
  const newArrivalsParam = searchParams.get("newArrivals");
  
  // Filter state
  const [filterOpen, setFilterOpen] = useState(!isMobile);
  const [selectedCategoryIds, setSelectedCategoryIds] = useState<number[]>([]);
  const [priceRange, setPriceRange] = useState<[number, number]>([0, PRICE_RANGE.max]);
  const [sortOption, setSortOption] = useState("default");
  const [localSearch, setLocalSearch] = useState(searchQuery || "");
  
  // Fetch categories
  const { data: categories } = useQuery({
    queryKey: ["/api/categories"],
  });
  
  // Fetch specific category if slug is provided
  const { data: selectedCategory } = useQuery({
    queryKey: ["/api/categories", categorySlug],
    queryFn: () => 
      categorySlug 
        ? fetch(`/api/categories/${categorySlug}`).then(res => res.json())
        : null,
    enabled: !!categorySlug
  });
  
  // Fetch all products
  const { 
    data: allProducts, 
    isLoading: isProductsLoading 
  } = useQuery({
    queryKey: ["/api/products", { search: searchQuery, category: categorySlug, newArrivals: newArrivalsParam }],
    queryFn: () => {
      let url = "/api/products";
      const params = new URLSearchParams();
      
      if (searchQuery) {
        params.append("search", searchQuery);
      }
      
      if (categorySlug && selectedCategory) {
        params.append("categoryId", selectedCategory.id.toString());
      }
      
      if (newArrivalsParam === "true") {
        params.append("newArrivals", "true");
      }
      
      if (params.toString()) {
        url += `?${params.toString()}`;
      }
      
      return fetch(url).then(res => res.json());
    }
  });
  
  // Update selected category based on URL param
  useEffect(() => {
    if (selectedCategory) {
      setSelectedCategoryIds([selectedCategory.id]);
    } else {
      setSelectedCategoryIds([]);
    }
  }, [selectedCategory]);
  
  // Format price for display
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('fr-CI').format(price);
  };
  
  // Filter and sort products
  const filteredProducts = useMemo(() => {
    if (!allProducts) return [];
    
    let filtered = [...allProducts];
    
    // Filter by selected categories if no category param in URL
    if (selectedCategoryIds.length > 0 && !categorySlug) {
      filtered = filtered.filter(product => 
        selectedCategoryIds.includes(product.categoryId)
      );
    }
    
    // Filter by price range
    filtered = filtered.filter(product => {
      const price = product.discountPrice || product.price;
      return price >= priceRange[0] && price <= priceRange[1];
    });
    
    // Sort products
    switch (sortOption) {
      case "price-asc":
        filtered.sort((a, b) => {
          const priceA = a.discountPrice || a.price;
          const priceB = b.discountPrice || b.price;
          return priceA - priceB;
        });
        break;
      case "price-desc":
        filtered.sort((a, b) => {
          const priceA = a.discountPrice || a.price;
          const priceB = b.discountPrice || b.price;
          return priceB - priceA;
        });
        break;
      case "newest":
        // For demo purposes, we'll assume products are sorted by ID
        filtered.sort((a, b) => b.id - a.id);
        break;
      case "rating":
        filtered.sort((a, b) => (b.rating || 0) - (a.rating || 0));
        break;
      default:
        // Default sorting (relevance)
        break;
    }
    
    return filtered;
  }, [allProducts, selectedCategoryIds, priceRange, sortOption, categorySlug]);
  
  // Handle category selection
  const handleCategoryChange = (categoryId: number, checked: boolean) => {
    setSelectedCategoryIds(prev => {
      if (checked) {
        return [...prev, categoryId];
      } else {
        return prev.filter(id => id !== categoryId);
      }
    });
  };
  
  // Handle price range change
  const handlePriceChange = (value: number[]) => {
    setPriceRange([value[0], value[1]]);
  };
  
  // Clear all filters
  const clearFilters = () => {
    setSelectedCategoryIds([]);
    setPriceRange([0, PRICE_RANGE.max]);
    setSortOption("default");
    setLocalSearch("");
    
    // Reset URL if there are filter params
    if (categorySlug || searchQuery || newArrivalsParam) {
      setLocation("/products");
    }
  };
  
  // Handle search
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (localSearch.trim()) {
      setLocation(`/products?search=${encodeURIComponent(localSearch)}`);
    } else if (searchQuery) {
      setLocation("/products");
    }
  };
  
  // Product loading skeleton
  const ProductSkeleton = () => (
    <>
      {[1, 2, 3, 4, 5, 6].map((i) => (
        <Card key={i} className="overflow-hidden">
          <Skeleton className="h-48 w-full" />
          <div className="p-4">
            <Skeleton className="h-6 w-3/4 mb-2" />
            <Skeleton className="h-4 w-1/2 mb-4" />
            <div className="flex justify-between">
              <Skeleton className="h-6 w-20" />
              <Skeleton className="h-10 w-24 rounded" />
            </div>
          </div>
        </Card>
      ))}
    </>
  );

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row gap-8">
        {/* Mobile filter toggle */}
        {isMobile && (
          <div className="md:hidden flex justify-between mb-4">
            <Button 
              variant="outline" 
              className="flex items-center gap-2"
              onClick={() => setFilterOpen(!filterOpen)}
            >
              <Filter size={16} />
              {t('products.filter.title')}
            </Button>
            
            <Select value={sortOption} onValueChange={setSortOption}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder={t('products.filter.sort')} />
              </SelectTrigger>
              <SelectContent>
                {SORT_OPTIONS.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        )}
        
        {/* Filters sidebar */}
        {filterOpen && (
          <div className="md:w-1/4 lg:w-1/5">
            <div className="bg-white p-4 rounded-lg shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold flex items-center">
                  <SlidersHorizontal size={18} className="mr-2" />
                  {t('products.filter.title')}
                </h2>
                <Button variant="ghost" size="sm" onClick={clearFilters}>
                  {t('products.filter.clearFilters')}
                </Button>
              </div>
              
              {/* Search */}
              <div className="mb-6">
                <form onSubmit={handleSearch}>
                  <div className="relative">
                    <Input
                      type="text"
                      placeholder={t('header.search')}
                      value={localSearch}
                      onChange={(e) => setLocalSearch(e.target.value)}
                      className="pr-10"
                    />
                    <Button 
                      type="submit" 
                      variant="ghost" 
                      size="icon"
                      className="absolute right-0 top-0 h-full"
                    >
                      <Search size={18} />
                    </Button>
                  </div>
                </form>
              </div>
              
              <Separator className="my-4" />
              
              {/* Category filter */}
              <Accordion type="single" collapsible defaultValue="categories">
                <AccordionItem value="categories">
                  <AccordionTrigger>{t('products.filter.category')}</AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-2 mt-2">
                      {categories?.map((category) => (
                        <div key={category.id} className="flex items-center space-x-2">
                          <Checkbox 
                            id={`category-${category.id}`}
                            checked={selectedCategoryIds.includes(category.id)}
                            onCheckedChange={(checked) => 
                              handleCategoryChange(category.id, checked as boolean)
                            }
                          />
                          <Label htmlFor={`category-${category.id}`}>
                            {category.name}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
              
              <Separator className="my-4" />
              
              {/* Price range filter */}
              <Accordion type="single" collapsible defaultValue="price">
                <AccordionItem value="price">
                  <AccordionTrigger>{t('products.filter.priceRange')}</AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-4 mt-2">
                      <Slider
                        defaultValue={[0, PRICE_RANGE.max]}
                        value={priceRange}
                        max={PRICE_RANGE.max}
                        step={5000}
                        onValueChange={handlePriceChange}
                        className="mt-6"
                      />
                      <div className="flex justify-between text-sm">
                        <span>
                          {formatPrice(priceRange[0])} {t('common.currency')}
                        </span>
                        <span>
                          {formatPrice(priceRange[1])} {t('common.currency')}
                        </span>
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
              
              {isMobile && (
                <Button 
                  className="w-full mt-4"
                  onClick={() => setFilterOpen(false)}
                >
                  {t('products.filter.apply')}
                </Button>
              )}
            </div>
          </div>
        )}
        
        {/* Products Grid */}
        <div className={`${filterOpen ? "md:w-3/4 lg:w-4/5" : "w-full"}`}>
          {/* Results header */}
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-2xl font-bold">
              {categorySlug && selectedCategory
                ? selectedCategory.name
                : searchQuery
                ? `${t('header.search')}: ${searchQuery}`
                : newArrivalsParam
                ? t('home.newArrivals.title')
                : t('footer.quickLinks.products')}
            </h1>
            
            {!isMobile && (
              <Select value={sortOption} onValueChange={setSortOption}>
                <SelectTrigger className="w-[200px]">
                  <SelectValue placeholder={t('products.filter.sort')} />
                </SelectTrigger>
                <SelectContent>
                  {SORT_OPTIONS.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {t(`products.filter.sortOptions.${option.value}`)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          </div>
          
          {isProductsLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              <ProductSkeleton />
            </div>
          ) : filteredProducts.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <p className="text-lg text-gray-500">{t('products.notFound')}</p>
              <Button variant="outline" onClick={clearFilters} className="mt-4">
                {t('products.filter.clearFilters')}
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
