import { useTranslation } from "react-i18next";
import { Link, useLocation } from "wouter";
import { useCart } from "@/hooks/useCart";
import { formatPrice } from "@/lib/utils";
import { CURRENCY } from "@/lib/constants";
import { Button } from "@/components/ui/button";
import { Helmet } from "react-helmet";

const Cart = () => {
  const { t } = useTranslation();
  const [, setLocation] = useLocation();
  const { 
    cartItems, 
    isLoading, 
    removeFromCart, 
    updateQuantity, 
    clearCart,
    subtotal 
  } = useCart();

  return (
    <>
      <Helmet>
        <title>Panier | TechMarket Côte d'Ivoire</title>
        <meta name="description" content="Voir et gérer votre panier d'achats sur TechMarket Côte d'Ivoire." />
      </Helmet>

      <main className="py-8">
        <div className="container mx-auto px-4">
          <div className="mb-6">
            <h1 className="text-3xl font-poppins font-bold text-secondary mb-2">
              Votre Panier
            </h1>
            <div className="flex items-center text-sm text-neutral-500">
              <a href="/" className="hover:text-primary">Accueil</a>
              <span className="mx-2">/</span>
              <span>Panier</span>
            </div>
          </div>

          {isLoading ? (
            <div className="flex justify-center items-center py-12">
              <div className="loader h-12 w-12 rounded-full border-4 border-neutral-200 border-t-primary animate-spin"></div>
            </div>
          ) : cartItems.length === 0 ? (
            <div className="bg-white rounded-lg shadow-sm p-8 text-center">
              <i className="fas fa-shopping-cart text-neutral-300 text-5xl mb-4"></i>
              <h2 className="text-2xl font-semibold text-neutral-700 mb-4">Votre panier est vide</h2>
              <p className="text-neutral-600 mb-6">
                Vous n'avez pas encore ajouté de produits à votre panier.
              </p>
              <Button 
                onClick={() => setLocation("/products")}
                className="bg-primary hover:bg-primary/90 text-white px-6 py-3 rounded-lg"
              >
                Voir nos produits
              </Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Cart Items */}
              <div className="lg:col-span-2">
                <div className="bg-white rounded-lg shadow-sm overflow-hidden">
                  <div className="hidden md:grid grid-cols-12 gap-4 p-4 border-b border-neutral-200 bg-neutral-50">
                    <div className="col-span-6">
                      <span className="font-medium text-neutral-700">Produit</span>
                    </div>
                    <div className="col-span-2 text-center">
                      <span className="font-medium text-neutral-700">Prix</span>
                    </div>
                    <div className="col-span-2 text-center">
                      <span className="font-medium text-neutral-700">Quantité</span>
                    </div>
                    <div className="col-span-2 text-right">
                      <span className="font-medium text-neutral-700">Total</span>
                    </div>
                  </div>

                  {cartItems.map((item) => {
                    const price = item.product.discountPrice || item.product.price;
                    const total = price * item.quantity;
                    
                    return (
                      <div key={item.id} className="p-4 border-b border-neutral-200 hover:bg-neutral-50">
                        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
                          {/* Product */}
                          <div className="md:col-span-6 flex items-center">
                            <div className="flex-shrink-0 mr-4">
                              <img 
                                src={item.product.imageUrl}
                                alt={item.product.name}
                                className="w-16 h-16 object-cover rounded"
                                loading="lazy"
                              />
                            </div>
                            <div>
                              <Link href={`/products/${item.product.slug}`}>
                                <a className="font-medium text-neutral-800 hover:text-primary">
                                  {item.product.name}
                                </a>
                              </Link>
                              <button 
                                onClick={() => removeFromCart(item.id)}
                                className="text-xs text-error hover:underline mt-1 flex items-center"
                              >
                                <i className="fas fa-trash-alt mr-1"></i> {t("cart.remove")}
                              </button>
                            </div>
                          </div>
                          
                          {/* Price */}
                          <div className="md:col-span-2 md:text-center">
                            <div className="flex items-center justify-between md:justify-center">
                              <span className="inline-block md:hidden font-medium text-neutral-700">Prix:</span>
                              <span className="text-neutral-700">
                                {formatPrice(price)} {CURRENCY}
                              </span>
                            </div>
                          </div>
                          
                          {/* Quantity */}
                          <div className="md:col-span-2 md:text-center">
                            <div className="flex items-center justify-between md:justify-center">
                              <span className="inline-block md:hidden font-medium text-neutral-700">{t("cart.quantity")}:</span>
                              <div className="flex items-center border border-neutral-300 rounded-lg overflow-hidden">
                                <button 
                                  onClick={() => updateQuantity(item.id, Math.max(1, item.quantity - 1))}
                                  className="px-2 py-1 bg-neutral-100 hover:bg-neutral-200"
                                >
                                  <i className="fas fa-minus text-xs"></i>
                                </button>
                                <span className="px-3 py-1">{item.quantity}</span>
                                <button 
                                  onClick={() => updateQuantity(item.id, item.quantity + 1)}
                                  className="px-2 py-1 bg-neutral-100 hover:bg-neutral-200"
                                >
                                  <i className="fas fa-plus text-xs"></i>
                                </button>
                              </div>
                            </div>
                          </div>
                          
                          {/* Total */}
                          <div className="md:col-span-2 md:text-right">
                            <div className="flex items-center justify-between md:justify-end">
                              <span className="inline-block md:hidden font-medium text-neutral-700">Total:</span>
                              <span className="font-medium text-primary">
                                {formatPrice(total)} {CURRENCY}
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}

                  <div className="p-4 flex justify-between items-center">
                    <Button 
                      onClick={() => setLocation("/products")}
                      variant="outline"
                      className="border border-neutral-300 text-neutral-700 hover:bg-neutral-100"
                    >
                      <i className="fas fa-arrow-left mr-2"></i> Continuer vos achats
                    </Button>
                    <Button 
                      onClick={() => clearCart()}
                      variant="outline"
                      className="border border-error text-error hover:bg-error hover:text-white"
                    >
                      <i className="fas fa-trash-alt mr-2"></i> Vider le panier
                    </Button>
                  </div>
                </div>
              </div>

              {/* Cart Summary */}
              <div className="lg:col-span-1">
                <div className="bg-white rounded-lg shadow-sm p-6">
                  <h2 className="text-xl font-semibold text-neutral-800 mb-6">
                    Résumé de la commande
                  </h2>
                  
                  <div className="space-y-4">
                    <div className="flex justify-between pb-4 border-b border-neutral-200">
                      <span className="text-neutral-600">{t("cart.subtotal")}</span>
                      <span className="font-medium text-neutral-800">
                        {formatPrice(subtotal)} {CURRENCY}
                      </span>
                    </div>
                    
                    <div className="flex justify-between pb-4 border-b border-neutral-200">
                      <span className="text-neutral-600">{t("cart.shipping")}</span>
                      <span className="text-neutral-600">{t("cart.shippingAtCheckout")}</span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span className="font-medium text-lg">{t("cart.total")}</span>
                      <span className="font-bold text-lg text-primary">
                        {formatPrice(subtotal)} {CURRENCY}
                      </span>
                    </div>
                  </div>
                  
                  <Button 
                    onClick={() => setLocation("/checkout")}
                    className="w-full bg-primary hover:bg-primary/90 text-white mt-6 py-3"
                  >
                    {t("cart.checkout")}
                  </Button>
                  
                  <div className="mt-6">
                    <h3 className="font-medium text-neutral-800 mb-2">Nous acceptons:</h3>
                    <div className="flex flex-wrap gap-2">
                      <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/b/b7/MasterCard_Logo.svg/200px-MasterCard_Logo.svg.png" alt="MasterCard" className="h-6" loading="lazy" />
                      <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/5e/Visa_Inc._logo.svg/200px-Visa_Inc._logo.svg.png" alt="Visa" className="h-6" loading="lazy" />
                      <img src="https://upload.wikimedia.org/wikipedia/fr/archive/0/04/20091026205430%21Orange_Money_logo_2013.png" alt="Orange Money" className="h-6" loading="lazy" />
                      <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e0/MTN_Mobile_Money_logo.svg/200px-MTN_Mobile_Money_logo.svg.png" alt="MTN Mobile Money" className="h-6" loading="lazy" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>
    </>
  );
};

export default Cart;
