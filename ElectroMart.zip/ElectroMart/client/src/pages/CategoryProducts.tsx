import { useTranslation } from "react-i18next";
import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import ProductGrid from "@/components/products/ProductGrid";
import { Product, Category } from "@shared/schema";
import { Helmet } from "react-helmet";

const CategoryProducts = () => {
  const { t } = useTranslation();
  const { slug } = useParams();
  
  // Fetch category
  const { 
    data: category,
    isLoading: categoryLoading,
    error: categoryError
  } = useQuery<Category>({
    queryKey: [`/api/categories/${slug}`],
  });
  
  // Fetch products by category
  const { 
    data: products = [],
    isLoading: productsLoading,
    error: productsError
  } = useQuery<Product[]>({
    queryKey: [`/api/products?categoryId=${category?.id}`],
    enabled: !!category?.id,
  });

  const isLoading = categoryLoading || productsLoading;
  const error = categoryError || productsError;

  return (
    <>
      {category && (
        <Helmet>
          <title>{category.name} | TechMarket Côte d'Ivoire</title>
          <meta name="description" content={category.description || `Découvrez notre gamme de ${category.name} en Côte d'Ivoire. Qualité et prix compétitifs garantis.`} />
        </Helmet>
      )}

      <main className="py-8">
        <div className="container mx-auto px-4">
          {categoryLoading ? (
            <div className="h-20 flex items-center justify-center">
              <div className="loader h-8 w-8 rounded-full border-4 border-neutral-200 border-t-primary animate-spin"></div>
            </div>
          ) : (
            <div className="mb-6">
              <h1 className="text-3xl font-poppins font-bold text-secondary mb-2">
                {category ? category.name : 'Catégorie non trouvée'}
              </h1>
              <div className="flex items-center text-sm text-neutral-500">
                <a href="/" className="hover:text-primary">Accueil</a>
                <span className="mx-2">/</span>
                <a href="/products" className="hover:text-primary">Produits</a>
                <span className="mx-2">/</span>
                <span>{category?.name}</span>
              </div>
            </div>
          )}

          {category && category.description && (
            <div className="bg-white p-6 rounded-lg shadow-sm mb-8">
              <p className="text-neutral-600">{category.description}</p>
            </div>
          )}

          <ProductGrid 
            products={products}
            isLoading={isLoading}
            error={error}
            showFilters={true}
          />
        </div>
      </main>
    </>
  );
};

export default CategoryProducts;
