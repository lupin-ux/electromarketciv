import { useTranslation } from "react-i18next";
import HeroBanner from "@/components/home/HeroBanner";
import CategoryBanner from "@/components/home/CategoryBanner";
import FeaturedProducts from "@/components/home/FeaturedProducts";
import FeaturedCategories from "@/components/home/FeaturedCategories";
import Benefits from "@/components/home/Benefits";
import Newsletter from "@/components/home/Newsletter";
import { Helmet } from "react-helmet";

const Home = () => {
  const { t } = useTranslation();

  return (
    <>
      <Helmet>
        <title>TechMarket Côte d'Ivoire | Laptops & Appareils Électroniques</title>
        <meta name="description" content="Découvrez notre sélection d'ordinateurs portables et d'appareils électroniques de qualité à des prix compétitifs en Côte d'Ivoire." />
      </Helmet>

      <main>
        <HeroBanner />
        <CategoryBanner />
        <FeaturedProducts />
        <FeaturedCategories />
        <Benefits />
        <Newsletter />
      </main>
    </>
  );
};

export default Home;
