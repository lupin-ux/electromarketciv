import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import ProductGrid from "@/components/products/ProductGrid";
import { Product } from "@shared/schema";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { debounce } from "@/lib/utils";
import { Helmet } from "react-helmet";

const SearchResults = () => {
  const { t } = useTranslation();
  const [location] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  
  // Get search query from URL
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const query = params.get("q");
    if (query) {
      setSearchQuery(query);
    }
  }, [location]);
  
  // Fetch search results
  const { 
    data: products = [],
    isLoading,
    error,
    refetch
  } = useQuery<Product[]>({
    queryKey: [`/api/products/search?q=${encodeURIComponent(searchQuery)}`],
    enabled: searchQuery.trim().length > 0,
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      refetch();
      
      // Update URL with search query
      const url = new URL(window.location.href);
      url.searchParams.set("q", searchQuery);
      window.history.pushState({}, "", url.toString());
    }
  };

  const debouncedSearch = debounce(() => {
    if (searchQuery.trim().length > 2) {
      refetch();
      
      // Update URL with search query
      const url = new URL(window.location.href);
      url.searchParams.set("q", searchQuery);
      window.history.pushState({}, "", url.toString());
    }
  }, 500);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);
    debouncedSearch();
  };

  return (
    <>
      <Helmet>
        <title>Résultats de recherche | TechMarket Côte d'Ivoire</title>
        <meta name="description" content={`Résultats de recherche pour "${searchQuery}" sur TechMarket Côte d'Ivoire.`} />
      </Helmet>

      <main className="py-8">
        <div className="container mx-auto px-4">
          <div className="mb-6">
            <h1 className="text-3xl font-poppins font-bold text-secondary mb-2">
              Résultats de recherche
            </h1>
            <div className="flex items-center text-sm text-neutral-500">
              <a href="/" className="hover:text-primary">Accueil</a>
              <span className="mx-2">/</span>
              <span>Recherche</span>
            </div>
          </div>

          {/* Search Form */}
          <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
            <form onSubmit={handleSearch} className="flex flex-col sm:flex-row gap-2">
              <Input
                type="search"
                placeholder="Rechercher des produits..."
                className="flex-grow"
                value={searchQuery}
                onChange={handleChange}
              />
              <Button type="submit" className="bg-primary hover:bg-primary/90 text-white px-6 whitespace-nowrap">
                <i className="fas fa-search mr-2"></i> Rechercher
              </Button>
            </form>
          </div>

          {searchQuery && (
            <div className="mb-6">
              <h2 className="text-xl font-semibold text-neutral-800">
                {isLoading ? (
                  "Recherche en cours..."
                ) : (
                  `Résultats pour "${searchQuery}" (${products.length} produit${products.length !== 1 ? 's' : ''})`
                )}
              </h2>
            </div>
          )}

          {searchQuery ? (
            <ProductGrid 
              products={products}
              isLoading={isLoading}
              error={error}
              showFilters={true}
            />
          ) : (
            <div className="text-center py-12">
              <i className="fas fa-search text-neutral-300 text-5xl mb-4"></i>
              <p className="text-neutral-600 text-lg mb-4">
                Veuillez entrer un terme de recherche pour trouver des produits.
              </p>
            </div>
          )}
        </div>
      </main>
    </>
  );
};

export default SearchResults;
