import { useTranslation } from "react-i18next";
import { COMPANY_INFO } from "@/lib/constants";
import Newsletter from "@/components/home/Newsletter";
import { Helmet } from "react-helmet";

const About = () => {
  const { t } = useTranslation();

  return (
    <>
      <Helmet>
        <title>À propos | TechMarket Côte d'Ivoire</title>
        <meta name="description" content="Découvrez TechMarket, votre partenaire technologique en Côte d'Ivoire. Qualité, service et expertise à votre service." />
      </Helmet>

      <main>
        {/* Hero Section */}
        <section className="bg-gradient-to-r from-secondary to-primary text-white py-12">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-3xl md:text-4xl font-poppins font-bold mb-4">
              {t("about.title")}
            </h1>
            <p className="text-xl max-w-2xl mx-auto">
              {t("about.description")}
            </p>
          </div>
        </section>

        {/* About Content */}
        <section className="py-12">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <div>
                <h2 className="text-2xl font-poppins font-semibold text-secondary mb-6">
                  Notre histoire
                </h2>
                <p className="text-neutral-600 mb-4">
                  Fondée en 2018, TechMarket est née de la passion pour la technologie et du désir d'offrir aux Ivoiriens un accès facile aux meilleurs produits électroniques du marché.
                </p>
                <p className="text-neutral-600 mb-4">
                  Notre équipe, composée d'experts passionnés, s'engage à vous proposer des produits de qualité, authentiques et au meilleur prix. Nous travaillons directement avec les fabricants et les distributeurs officiels pour garantir l'origine de nos produits.
                </p>
                <p className="text-neutral-600">
                  Aujourd'hui, TechMarket est devenu une référence en Côte d'Ivoire pour l'achat d'ordinateurs portables, smartphones, tablettes et accessoires électroniques.
                </p>
              </div>
              <div className="rounded-lg overflow-hidden shadow-lg">
                <img 
                  src="https://images.unsplash.com/photo-1528901166007-3784c7dd3653?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80" 
                  alt="Notre équipe TechMarket" 
                  className="w-full h-auto"
                  loading="lazy"
                />
              </div>
            </div>
          </div>
        </section>

        {/* Mission & Values */}
        <section className="py-12 bg-accent">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
              <div className="bg-white p-8 rounded-lg shadow-sm">
                <h2 className="text-2xl font-poppins font-semibold text-secondary mb-6">
                  {t("about.mission")}
                </h2>
                <p className="text-neutral-600 mb-4">
                  Notre mission est de démocratiser l'accès à la technologie en Côte d'Ivoire en proposant des produits de qualité à des prix compétitifs, accompagnés d'un service client exceptionnel.
                </p>
                <p className="text-neutral-600">
                  Nous nous efforçons de rendre la technologie accessible à tous, en offrant des solutions adaptées aux besoins et au budget de chacun.
                </p>
              </div>
              <div className="bg-white p-8 rounded-lg shadow-sm">
                <h2 className="text-2xl font-poppins font-semibold text-secondary mb-6">
                  {t("about.values")}
                </h2>
                <ul className="space-y-3">
                  <li className="flex items-start">
                    <i className="fas fa-check-circle text-primary mt-1 mr-3"></i>
                    <span className="text-neutral-600"><span className="font-medium">Qualité :</span> Nous ne proposons que des produits authentiques et de qualité.</span>
                  </li>
                  <li className="flex items-start">
                    <i className="fas fa-check-circle text-primary mt-1 mr-3"></i>
                    <span className="text-neutral-600"><span className="font-medium">Service client :</span> La satisfaction de nos clients est notre priorité absolue.</span>
                  </li>
                  <li className="flex items-start">
                    <i className="fas fa-check-circle text-primary mt-1 mr-3"></i>
                    <span className="text-neutral-600"><span className="font-medium">Transparence :</span> Nous pratiquons des prix justes et transparents.</span>
                  </li>
                  <li className="flex items-start">
                    <i className="fas fa-check-circle text-primary mt-1 mr-3"></i>
                    <span className="text-neutral-600"><span className="font-medium">Innovation :</span> Nous suivons les tendances pour vous proposer les dernières technologies.</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        {/* Team Section */}
        <section className="py-12">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-2xl md:text-3xl font-poppins font-semibold text-secondary mb-8">
              {t("about.team")}
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {/* Team Member 1 */}
              <div className="bg-white rounded-lg shadow-sm overflow-hidden">
                <img 
                  src="https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80" 
                  alt="Directeur Général" 
                  className="w-full h-64 object-cover"
                  loading="lazy"
                />
                <div className="p-4">
                  <h3 className="font-semibold text-lg">Amadou Koné</h3>
                  <p className="text-primary text-sm mb-2">Directeur Général</p>
                  <p className="text-neutral-600 text-sm">
                    Passionné de technologie avec plus de 15 ans d'expérience dans le secteur.
                  </p>
                </div>
              </div>
              
              {/* Team Member 2 */}
              <div className="bg-white rounded-lg shadow-sm overflow-hidden">
                <img 
                  src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80" 
                  alt="Responsable Commercial" 
                  className="w-full h-64 object-cover"
                  loading="lazy"
                />
                <div className="p-4">
                  <h3 className="font-semibold text-lg">Marie Touré</h3>
                  <p className="text-primary text-sm mb-2">Responsable Commerciale</p>
                  <p className="text-neutral-600 text-sm">
                    Experte en relations clients et en développement commercial.
                  </p>
                </div>
              </div>
              
              {/* Team Member 3 */}
              <div className="bg-white rounded-lg shadow-sm overflow-hidden">
                <img 
                  src="https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80" 
                  alt="Responsable Technique" 
                  className="w-full h-64 object-cover"
                  loading="lazy"
                />
                <div className="p-4">
                  <h3 className="font-semibold text-lg">Paul Diallo</h3>
                  <p className="text-primary text-sm mb-2">Responsable Technique</p>
                  <p className="text-neutral-600 text-sm">
                    Ingénieur en informatique spécialisé dans le support et les réparations.
                  </p>
                </div>
              </div>
              
              {/* Team Member 4 */}
              <div className="bg-white rounded-lg shadow-sm overflow-hidden">
                <img 
                  src="https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-1.2.1&auto=format&fit=crop&w=300&q=80" 
                  alt="Responsable Marketing" 
                  className="w-full h-64 object-cover"
                  loading="lazy"
                />
                <div className="p-4">
                  <h3 className="font-semibold text-lg">Aya Bamba</h3>
                  <p className="text-primary text-sm mb-2">Responsable Marketing</p>
                  <p className="text-neutral-600 text-sm">
                    Créative et passionnée par les stratégies digitales et le e-commerce.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Contact Info */}
        <section className="py-12 bg-neutral-50">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-2xl font-poppins font-semibold text-secondary mb-6">
              Contactez-nous
            </h2>
            <p className="text-neutral-600 mb-8 max-w-2xl mx-auto">
              Vous avez des questions ou souhaitez en savoir plus sur nos produits ? Contactez-nous dès maintenant !
            </p>
            <div className="flex flex-wrap justify-center gap-6">
              <div className="flex items-center">
                <i className="fas fa-map-marker-alt text-primary text-xl mr-3"></i>
                <span className="text-neutral-700">{COMPANY_INFO.address}</span>
              </div>
              <div className="flex items-center">
                <i className="fas fa-phone-alt text-primary text-xl mr-3"></i>
                <span className="text-neutral-700">{COMPANY_INFO.phone}</span>
              </div>
              <div className="flex items-center">
                <i className="fas fa-envelope text-primary text-xl mr-3"></i>
                <span className="text-neutral-700">{COMPANY_INFO.email}</span>
              </div>
            </div>
          </div>
        </section>

        <Newsletter />
      </main>
    </>
  );
};

export default About;
