import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useCart } from "@/hooks/useCart";
import { formatPrice } from "@/lib/utils";
import { CURRENCY, PAYMENT_METHODS } from "@/lib/constants";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Helmet } from "react-helmet";

// Form validation schema
const checkoutSchema = z.object({
  fullName: z.string().min(3, "Le nom complet est requis"),
  email: z.string().email("Email invalide"),
  phoneNumber: z.string().min(10, "Numéro de téléphone invalide"),
  address: z.string().min(5, "Adresse requise"),
  city: z.string().min(2, "Ville requise"),
  paymentMethod: z.enum(["card", "orange-money", "mtn-mobile-money", "cash-on-delivery"])
});

type CheckoutFormData = z.infer<typeof checkoutSchema>;

const Checkout = () => {
  const { t } = useTranslation();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { cartItems, subtotal, clearCart } = useCart();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const { 
    register, 
    handleSubmit, 
    formState: { errors },
    watch
  } = useForm<CheckoutFormData>({
    resolver: zodResolver(checkoutSchema),
    defaultValues: {
      paymentMethod: "cash-on-delivery"
    }
  });

  const selectedPaymentMethod = watch("paymentMethod");

  const onSubmit = async (data: CheckoutFormData) => {
    if (cartItems.length === 0) {
      toast({
        title: "Erreur",
        description: "Votre panier est vide",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);

    try {
      // Create order
      await apiRequest('POST', '/api/orders', {
        shippingAddress: `${data.address}, ${data.city}`,
        paymentMethod: data.paymentMethod
      });

      toast({
        title: "Commande confirmée",
        description: "Votre commande a été traitée avec succès.",
      });

      // Clear cart and redirect to success page
      await clearCart();
      setLocation("/");
    } catch (error) {
      console.error("Error creating order:", error);
      toast({
        title: "Erreur",
        description: "Une erreur s'est produite lors de la commande. Veuillez réessayer.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (cartItems.length === 0 && !isSubmitting) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <h1 className="text-2xl font-bold text-neutral-800 mb-4">Votre panier est vide</h1>
        <p className="text-neutral-600 mb-6">
          Vous devez ajouter des produits à votre panier avant de passer à la caisse.
        </p>
        <Button 
          onClick={() => setLocation("/products")} 
          className="bg-primary text-white px-4 py-2 rounded-lg hover:bg-primary/90"
        >
          Voir nos produits
        </Button>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Finaliser la commande | TechMarket Côte d'Ivoire</title>
        <meta name="description" content="Complétez votre achat et finalisez votre commande sur TechMarket Côte d'Ivoire." />
      </Helmet>

      <main className="py-8">
        <div className="container mx-auto px-4">
          <div className="mb-6">
            <h1 className="text-3xl font-poppins font-bold text-secondary mb-2">
              {t("checkout.title")}
            </h1>
            <div className="flex items-center text-sm text-neutral-500">
              <a href="/" className="hover:text-primary">Accueil</a>
              <span className="mx-2">/</span>
              <a href="/cart" className="hover:text-primary">Panier</a>
              <span className="mx-2">/</span>
              <span>Paiement</span>
            </div>
          </div>

          <form onSubmit={handleSubmit(onSubmit)}>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Customer Information */}
              <div className="lg:col-span-2 space-y-6">
                {/* Contact Information */}
                <div className="bg-white rounded-lg shadow-sm p-6">
                  <h2 className="text-xl font-semibold text-neutral-800 mb-6">
                    {t("checkout.contactInfo")}
                  </h2>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="fullName" className="block text-sm font-medium text-neutral-700 mb-1">
                        Nom complet *
                      </label>
                      <Input
                        id="fullName"
                        {...register("fullName")}
                        placeholder="Entrez votre nom complet"
                        className={errors.fullName ? "border-error" : ""}
                      />
                      {errors.fullName && (
                        <p className="text-error text-xs mt-1">{errors.fullName.message}</p>
                      )}
                    </div>
                    
                    <div>
                      <label htmlFor="email" className="block text-sm font-medium text-neutral-700 mb-1">
                        Email *
                      </label>
                      <Input
                        id="email"
                        type="email"
                        {...register("email")}
                        placeholder="Entrez votre adresse email"
                        className={errors.email ? "border-error" : ""}
                      />
                      {errors.email && (
                        <p className="text-error text-xs mt-1">{errors.email.message}</p>
                      )}
                    </div>
                    
                    <div>
                      <label htmlFor="phoneNumber" className="block text-sm font-medium text-neutral-700 mb-1">
                        Téléphone *
                      </label>
                      <Input
                        id="phoneNumber"
                        {...register("phoneNumber")}
                        placeholder="Entrez votre numéro de téléphone"
                        className={errors.phoneNumber ? "border-error" : ""}
                      />
                      {errors.phoneNumber && (
                        <p className="text-error text-xs mt-1">{errors.phoneNumber.message}</p>
                      )}
                    </div>
                  </div>
                </div>
                
                {/* Shipping Address */}
                <div className="bg-white rounded-lg shadow-sm p-6">
                  <h2 className="text-xl font-semibold text-neutral-800 mb-6">
                    {t("checkout.shippingAddress")}
                  </h2>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="md:col-span-2">
                      <label htmlFor="address" className="block text-sm font-medium text-neutral-700 mb-1">
                        Adresse *
                      </label>
                      <Textarea
                        id="address"
                        {...register("address")}
                        placeholder="Entrez votre adresse de livraison"
                        className={errors.address ? "border-error" : ""}
                      />
                      {errors.address && (
                        <p className="text-error text-xs mt-1">{errors.address.message}</p>
                      )}
                    </div>
                    
                    <div>
                      <label htmlFor="city" className="block text-sm font-medium text-neutral-700 mb-1">
                        Ville *
                      </label>
                      <Input
                        id="city"
                        {...register("city")}
                        placeholder="Entrez votre ville"
                        className={errors.city ? "border-error" : ""}
                      />
                      {errors.city && (
                        <p className="text-error text-xs mt-1">{errors.city.message}</p>
                      )}
                    </div>
                  </div>
                </div>
                
                {/* Payment Method */}
                <div className="bg-white rounded-lg shadow-sm p-6">
                  <h2 className="text-xl font-semibold text-neutral-800 mb-6">
                    {t("checkout.paymentMethod")}
                  </h2>
                  
                  <RadioGroup 
                    onValueChange={(value) => {}} 
                    defaultValue="cash-on-delivery"
                    className="space-y-4"
                  >
                    {PAYMENT_METHODS.map((method) => (
                      <div key={method.value} className="flex items-center space-x-2">
                        <RadioGroupItem 
                          value={method.value} 
                          id={`payment-${method.value}`}
                          {...register("paymentMethod")}
                          checked={selectedPaymentMethod === method.value}
                        />
                        <Label 
                          htmlFor={`payment-${method.value}`}
                          className="flex items-center cursor-pointer"
                        >
                          {method.name}
                        </Label>
                      </div>
                    ))}
                  </RadioGroup>
                  
                  {selectedPaymentMethod === "orange-money" && (
                    <div className="mt-4 p-4 bg-neutral-50 rounded-lg">
                      <p className="text-sm text-neutral-600">
                        Pour payer avec Orange Money, veuillez suivre les instructions que vous recevrez par SMS après avoir passé votre commande.
                      </p>
                    </div>
                  )}
                  
                  {selectedPaymentMethod === "mtn-mobile-money" && (
                    <div className="mt-4 p-4 bg-neutral-50 rounded-lg">
                      <p className="text-sm text-neutral-600">
                        Pour payer avec MTN Mobile Money, veuillez suivre les instructions que vous recevrez par SMS après avoir passé votre commande.
                      </p>
                    </div>
                  )}
                </div>
              </div>

              {/* Order Summary */}
              <div className="lg:col-span-1">
                <div className="bg-white rounded-lg shadow-sm p-6 sticky top-20">
                  <h2 className="text-xl font-semibold text-neutral-800 mb-6">
                    {t("checkout.orderSummary")}
                  </h2>
                  
                  <div className="space-y-4 mb-6">
                    {cartItems.map((item) => {
                      const price = item.product.discountPrice || item.product.price;
                      const total = price * item.quantity;
                      
                      return (
                        <div key={item.id} className="flex justify-between">
                          <div className="flex items-start">
                            <img 
                              src={item.product.imageUrl}
                              alt={item.product.name}
                              className="w-12 h-12 object-cover rounded mr-3"
                              loading="lazy"
                            />
                            <div>
                              <p className="text-neutral-800 font-medium">{item.product.name}</p>
                              <p className="text-neutral-500 text-sm">Quantité: {item.quantity}</p>
                            </div>
                          </div>
                          <span className="font-medium text-neutral-800">
                            {formatPrice(total)} {CURRENCY}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                  
                  <div className="space-y-4">
                    <div className="flex justify-between pb-4 border-b border-neutral-200">
                      <span className="text-neutral-600">{t("cart.subtotal")}</span>
                      <span className="font-medium text-neutral-800">
                        {formatPrice(subtotal)} {CURRENCY}
                      </span>
                    </div>
                    
                    <div className="flex justify-between pb-4 border-b border-neutral-200">
                      <span className="text-neutral-600">{t("cart.shipping")}</span>
                      <span className="text-neutral-600">{t("cart.shippingAtCheckout")}</span>
                    </div>
                    
                    <div className="flex justify-between">
                      <span className="font-medium text-lg">{t("cart.total")}</span>
                      <span className="font-bold text-lg text-primary">
                        {formatPrice(subtotal)} {CURRENCY}
                      </span>
                    </div>
                  </div>
                  
                  <Button 
                    type="submit"
                    className="w-full bg-primary hover:bg-primary/90 text-white mt-6 py-3"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? (
                      <span className="flex items-center justify-center">
                        <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        Traitement en cours...
                      </span>
                    ) : (
                      t("checkout.placeOrder")
                    )}
                  </Button>
                  
                  <p className="text-xs text-neutral-500 mt-4 text-center">
                    En passant votre commande, vous acceptez nos conditions générales de vente.
                  </p>
                </div>
              </div>
            </div>
          </form>
        </div>
      </main>
    </>
  );
};

export default Checkout;
