import { useState } from "react";
import { useTranslation } from "react-i18next";
import { Link } from "wouter";
import { useCart } from "@/components/cart-provider";
import { 
  Card, 
  CardContent, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Input } from "@/components/ui/input";
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from "@/components/ui/table";
import {
  ShoppingBag,
  Trash2,
  Plus,
  Minus,
  RefreshCw,
  CreditCard
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Cart() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const { 
    items, 
    isLoading, 
    updateQuantity, 
    removeFromCart, 
    clearCart, 
    totalItems, 
    totalPrice 
  } = useCart();
  
  const [checkoutInProgress, setCheckoutInProgress] = useState(false);
  
  // Handle checkout (this would normally connect to a payment gateway)
  const handleCheckout = () => {
    setCheckoutInProgress(true);
    
    // Simulate checkout process
    setTimeout(() => {
      toast({
        title: "Fonction simulée",
        description: "La fonctionnalité de paiement n'est pas implémentée dans cette démo",
      });
      setCheckoutInProgress(false);
    }, 1500);
  };
  
  // Format price
  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('fr-CI').format(price);
  };
  
  // Empty cart view
  if (!isLoading && totalItems === 0) {
    return (
      <div className="container mx-auto px-4 py-12">
        <Card className="max-w-3xl mx-auto">
          <CardHeader>
            <CardTitle className="text-2xl">{t('cart.title')}</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col items-center py-8">
            <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mb-4">
              <ShoppingBag className="h-10 w-10 text-gray-400" />
            </div>
            <h2 className="text-xl font-semibold mb-2">{t('cart.empty')}</h2>
            <p className="text-gray-500 mb-6">Ajoutez des produits à votre panier pour continuer</p>
            <Button asChild>
              <Link href="/products">{t('cart.continueShopping')}</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold mb-8">{t('cart.title')}</h1>
      
      <div className="grid md:grid-cols-3 gap-8">
        {/* Cart items */}
        <div className="md:col-span-2">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle>{totalItems} {totalItems === 1 ? 'article' : 'articles'}</CardTitle>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={clearCart}
                  className="text-gray-500"
                >
                  <RefreshCw className="mr-2 h-4 w-4" />
                  {t('cart.clear')}
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="flex justify-center items-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary-600"></div>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>{t('cart.product')}</TableHead>
                        <TableHead className="text-right">{t('cart.price')}</TableHead>
                        <TableHead className="text-center">{t('cart.quantity')}</TableHead>
                        <TableHead className="text-right">{t('cart.total')}</TableHead>
                        <TableHead></TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {items.map((item) => {
                        const price = item.product.discountPrice || item.product.price;
                        const itemTotal = price * item.quantity;
                        
                        return (
                          <TableRow key={item.id}>
                            <TableCell>
                              <div className="flex items-center">
                                <div className="w-12 h-12 mr-3 bg-gray-100 rounded overflow-hidden">
                                  <img 
                                    src={item.product.imageUrl} 
                                    alt={item.product.name}
                                    className="w-full h-full object-cover"
                                  />
                                </div>
                                <div>
                                  <Link 
                                    href={`/products/${item.product.slug}`}
                                    className="font-medium hover:text-primary-600"
                                  >
                                    {item.product.name}
                                  </Link>
                                </div>
                              </div>
                            </TableCell>
                            <TableCell className="text-right">
                              {formatPrice(price)} {t('common.currency')}
                            </TableCell>
                            <TableCell>
                              <div className="flex items-center justify-center">
                                <Button 
                                  variant="outline" 
                                  size="icon" 
                                  className="h-8 w-8"
                                  onClick={() => updateQuantity(item.id, item.quantity - 1)}
                                >
                                  <Minus className="h-3 w-3" />
                                </Button>
                                <Input
                                  type="number"
                                  className="h-8 w-12 mx-1 text-center"
                                  value={item.quantity}
                                  min={1}
                                  onChange={(e) => {
                                    const val = parseInt(e.target.value);
                                    if (!isNaN(val) && val >= 1) {
                                      updateQuantity(item.id, val);
                                    }
                                  }}
                                />
                                <Button 
                                  variant="outline" 
                                  size="icon" 
                                  className="h-8 w-8"
                                  onClick={() => updateQuantity(item.id, item.quantity + 1)}
                                >
                                  <Plus className="h-3 w-3" />
                                </Button>
                              </div>
                            </TableCell>
                            <TableCell className="text-right font-medium">
                              {formatPrice(itemTotal)} {t('common.currency')}
                            </TableCell>
                            <TableCell>
                              <Button 
                                variant="ghost" 
                                size="icon" 
                                className="text-gray-500 hover:text-red-600"
                                onClick={() => removeFromCart(item.id)}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
            <CardFooter>
              <Button 
                variant="outline" 
                asChild
                className="w-full md:w-auto"
              >
                <Link href="/products">
                  {t('cart.continueShopping')}
                </Link>
              </Button>
            </CardFooter>
          </Card>
        </div>
        
        {/* Order summary */}
        <div>
          <Card>
            <CardHeader>
              <CardTitle>Récapitulatif de commande</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between">
                <span className="text-gray-600">{t('cart.subtotal')}</span>
                <span>{formatPrice(totalPrice)} {t('common.currency')}</span>
              </div>
              
              <div className="flex justify-between">
                <span className="text-gray-600">{t('cart.shipping')}</span>
                <span>2.000 {t('common.currency')}</span>
              </div>
              
              <div className="flex justify-between">
                <span className="text-gray-600">{t('cart.tax')}</span>
                <span>Incluse</span>
              </div>
              
              <Separator />
              
              <div className="flex justify-between font-bold text-lg">
                <span>{t('cart.orderTotal')}</span>
                <span>{formatPrice(totalPrice + 2000)} {t('common.currency')}</span>
              </div>
              
              <Button 
                className="w-full bg-primary-600 hover:bg-primary-700 mt-6"
                onClick={handleCheckout}
                disabled={checkoutInProgress || items.length === 0}
              >
                {checkoutInProgress ? (
                  <span className="flex items-center">
                    <span className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></span>
                    Traitement...
                  </span>
                ) : (
                  <span className="flex items-center">
                    <CreditCard className="mr-2 h-5 w-5" />
                    {t('cart.checkout')}
                  </span>
                )}
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
