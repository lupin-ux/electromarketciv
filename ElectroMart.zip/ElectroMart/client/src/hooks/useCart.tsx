import { useContext } from "react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { CartItemWithProduct } from "@shared/schema";

export function useCart() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch cart items
  const { 
    data: cartItems = [], 
    isLoading, 
    error 
  } = useQuery<CartItemWithProduct[]>({
    queryKey: ['/api/cart'],
  });

  // Calculate subtotal and item count
  const subtotal = cartItems.reduce((sum, item) => {
    const price = item.product.discountPrice || item.product.price;
    return sum + (price * item.quantity);
  }, 0);
  
  const itemCount = cartItems.reduce((count, item) => count + item.quantity, 0);

  // Add to cart mutation
  const addToCartMutation = useMutation({
    mutationFn: async ({ productId, quantity }: { productId: number, quantity: number }) => {
      const response = await apiRequest('POST', '/api/cart', { productId, quantity });
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
      toast({
        title: "Produit ajouté au panier",
        description: "Le produit a été ajouté à votre panier avec succès.",
      });
    },
    onError: (error) => {
      toast({
        title: "Erreur",
        description: "Impossible d'ajouter le produit au panier. Veuillez réessayer.",
        variant: "destructive",
      });
      console.error("Error adding to cart:", error);
    },
  });

  // Update cart item mutation
  const updateQuantityMutation = useMutation({
    mutationFn: async ({ cartItemId, quantity }: { cartItemId: number, quantity: number }) => {
      const response = await apiRequest('PUT', `/api/cart/${cartItemId}`, { quantity });
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
    },
    onError: (error) => {
      toast({
        title: "Erreur",
        description: "Impossible de mettre à jour la quantité. Veuillez réessayer.",
        variant: "destructive",
      });
      console.error("Error updating quantity:", error);
    },
  });

  // Remove from cart mutation
  const removeFromCartMutation = useMutation({
    mutationFn: async (cartItemId: number) => {
      await apiRequest('DELETE', `/api/cart/${cartItemId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
      toast({
        title: "Produit retiré",
        description: "Le produit a été retiré de votre panier.",
      });
    },
    onError: (error) => {
      toast({
        title: "Erreur",
        description: "Impossible de retirer le produit du panier. Veuillez réessayer.",
        variant: "destructive",
      });
      console.error("Error removing from cart:", error);
    },
  });

  // Clear cart mutation
  const clearCartMutation = useMutation({
    mutationFn: async () => {
      await apiRequest('DELETE', '/api/cart');
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
      toast({
        title: "Panier vidé",
        description: "Votre panier a été vidé avec succès.",
      });
    },
    onError: (error) => {
      toast({
        title: "Erreur",
        description: "Impossible de vider le panier. Veuillez réessayer.",
        variant: "destructive",
      });
      console.error("Error clearing cart:", error);
    },
  });

  // Function to add product to cart
  const addToCart = async (productId: number, quantity: number) => {
    await addToCartMutation.mutateAsync({ productId, quantity });
  };

  // Function to update item quantity
  const updateQuantity = async (cartItemId: number, quantity: number) => {
    await updateQuantityMutation.mutateAsync({ cartItemId, quantity });
  };

  // Function to remove item from cart
  const removeFromCart = async (cartItemId: number) => {
    await removeFromCartMutation.mutateAsync(cartItemId);
  };

  // Function to clear cart
  const clearCart = async () => {
    await clearCartMutation.mutateAsync();
  };

  return {
    cartItems,
    isLoading,
    error,
    addToCart,
    updateQuantity,
    removeFromCart,
    clearCart,
    subtotal,
    itemCount,
  };
}
